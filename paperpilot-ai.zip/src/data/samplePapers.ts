import { FolderItem, PaperDocument } from '../types';

export const sampleFolders: FolderItem[] = [
  { id: 'f-anti-aging', name: 'Other anti-aging interventions', parentId: null, isOpen: true },
  { id: 'f-parabiosis', name: 'Parabiosis & young blood', parentId: 'f-anti-aging' },
  { id: 'f-mtor', name: 'mTOR, rapamycin & auto...', parentId: 'f-anti-aging' },
  { id: 'f-nad', name: 'NAD+ & sirtuins', parentId: 'f-anti-aging' },
  { id: 'f-senolytics', name: 'Senolytics', parentId: 'f-anti-aging' },

  { id: 'f-yamanaka', name: 'Yamanaka factors & reprogr...', parentId: null, isOpen: false },
  { id: 'f-chemical', name: 'Chemical & non-integrati...', parentId: 'f-yamanaka' },
  { id: 'f-mechanisms', name: 'Mechanisms of reprogra...', parentId: 'f-yamanaka' },
  { id: 'f-oskm', name: 'Foundational OSKM disc...', parentId: 'f-yamanaka' },

  { id: 'f-biomarkers', name: 'Aging biomarkers & clocks', parentId: null, isOpen: true },
  { id: 'f-multiomic', name: 'Multi-omic biological age', parentId: 'f-biomarkers' },
  { id: 'f-epigenetic', name: 'Epigenetic clocks', parentId: 'f-biomarkers' },

  { id: 'f-biology', name: 'Biology of aging', parentId: null, isOpen: false },
  { id: 'f-stemcell', name: 'Stem cell aging & nich...', parentId: 'f-biology' },
  { id: 'f-telomeres', name: 'Telomeres', parentId: 'f-biology' },
  { id: 'f-senescence', name: 'Cellular senescence &...', parentId: 'f-biology' },
];

export const samplePapers: PaperDocument[] = [
  {
    id: 'paper-horvath-2013',
    title: 'DNA methylation age of human tissues and cell types',
    shortTitle: 'DNA methylat...',
    authors: ['Steve Horvath'],
    year: 2013,
    journalOrConference: 'Genome Biology 14:R115',
    doi: '10.1186/gb-2013-14-10-r115',
    citationsCount: 5420,
    abstract: 'DNA methylation can accurately track chronological age across virtually all human cell types and solid tissues. Here, we present an elastic net penalized multi-tissue age predictor based on 353 CpG sites that operates accurately across brain, breast, colon, heart, kidney, liver, lung, and muscle without requiring tissue-specific calibration.',
    totalPages: 19,
    fileType: 'pdf',
    fileName: 'horvath_genome_biology_2013.pdf',
    fileSize: '3.4 MB',
    folderId: 'f-epigenetic',
    collection: 'Epigenetic clocks',
    tags: ['Epigenetics', 'Biological Clocks', 'DNA Methylation', 'Twin Studies'],
    createdAt: Date.now() - 86400000 * 30,
    bibtex: `@article{horvath2013dna,
  title={DNA methylation age of human tissues and cell types},
  author={Horvath, Steve},
  journal={Genome Biology},
  volume={14},
  number={10},
  pages={R115},
  year={2013},
  publisher={BioMed Central}
}`,
    pages: [
      {
        pageNumber: 1,
        headerText: 'Horvath Genome Biology, 14:R115 http://genomebiology.com/14/10/R115',
        footerText: 'Page 1 of 19',
        text: `RESEARCH Open Access
DNA methylation age of human tissues and cell types
Steve Horvath*

Abstract
Significant age-associated changes in DNA methylation patterns have been recognized across diverse human organs. However, whether a single universal molecular metric could measure chronological age across both embryonic and differentiated tissues remained controversial. Here, using penalised regression across 8,000 Illumina DNA methylation arrays from 51 healthy tissues and cell types, we develop a multi-tissue biomarker of aging known as the epigenetic clock. The clock calibrates 353 CpG dinucleotides, achieving a Pearson correlation of r = 0.96 with chronological age in independent validation datasets, with a median absolute prediction error of 3.6 years across all tested anatomical structures.`
      },
      {
        pageNumber: 2,
        headerText: 'Horvath Genome Biology, 14:R115 http://genomebiology.com/14/10/R115',
        footerText: 'Page 2 of 19',
        text: `Background
Aging is associated with marked changes in DNA methylation throughout human ontogeny and senescence. Previous tissue-specific algorithms required separate parameter tuning for saliva, peripheral blood, or brain parenchyma. A critical challenge was to determine if human aging exhibits an organ-wide coordinated program, or if each tissue accumulates somatic epimutations at autonomous, uncoupled tempos.

Results: Multi-tissue algorithm calibration
To construct an organ-agnostic measure, we compiled 39 publicly accessible datasets containing 8,000 array profiles covering diverse developmental windows from fetus to supercentenarian (100+ years). Elastic net regression selected 353 CpG sites (193 positively correlated with age, 160 negatively correlated). The resulting mathematical model defines DNAm age.`
      },
      {
        pageNumber: 3,
        headerText: 'Horvath Genome Biology, 14:R115 http://genomebiology.com/14/10/R115',
        footerText: 'Page 3 of 19',
        text: `Validation in non-transformed and transformed tissues
To assess the generalizability of the multi-tissue predictor, we tested its accuracy on independent test sets comprising 32 non-overlapping cohorts. We observed remarkable predictive fidelity in saliva, peripheral blood mononuclear cells (PBMC), whole blood, CD4+ T-cells, CD14+ monocytes, adipose tissue, skeletal muscle, myocardium, cortical brain, and kidney parenchyma.
Notably, induced pluripotent stem cells (iPSCs) derived from elderly dermal fibroblasts displayed an estimated DNAm age indistinguishable from embryonic zero, demonstrating that epigenetic remodeling resets the clock.`
      },
      {
        pageNumber: 4,
        headerText: 'Horvath Genome Biology, 14:R115 http://genomebiology.com/14/10/R115',
        footerText: 'Page 4 of 19',
        text: `Figure 2 Chronological age (y-axis) versus DNAm age (x-axis) in the test data. (A) Across all test data, the age correlation is 0.96 and the error is 3.6 years. Results for (B) CD4 T cells measured at birth (age zero) and at age 104 (cor = 0.78, error = 0.27 years), (C) CD4 T cells and CD14 monocytes (cor = 0.90, error = 3.7), (D) peripheral blood mononuclear cells (cor = 0.96, error = 1.9), (E) Whole blood (cor = 0.95, error = 18), (F) Brain Cerebellar cortex (cor = 0.92, error = 5.9), (G) Occipital cortex (cor = 0.98, error = 1.5), (H) Normal adjacent breast tissue (cor = 0.87, error = 13), (I) buccal epithelium (cor = 0.83, error = 0.37), (J) colon (cor = 0.85, error = 5.6), (K) Fat adipose (cor = 0.65, error = 2.7), (L) Heart (cor = 0.77, error = 12), (M) kidney (cor = 0.86, error = 4.6), (N) liver (cor = 0.89, error = 6.7), (O) lung (cor = 0.87, error = 5.2), (P) muscle (cor = 0.70, error = 18), (Q) saliva (cor = 0.83, error = 2.7), (R) uterine cervix (cor = 0.75, error = 6.2), (S) uterine endometrium (cor = 0.55, 11), (T) various blood samples composed of 10 Epstein Barr Virus transformed B cell, three naive B cell, and three peripheral blood mononuclear cell samples (cor = 0.46, error = 4.4). Samples are colored by disease status: brown for Werner progeroid syndrome, blue for Hutchinson-Gilford progeria, and turquoise for healthy control subjects.

(Age, DNAmAge)' and 'Median Error(Age, DNAmAge)' in Additional file 1). An obvious limitation of this approach is that it leads to biased results in the training data sets. As suggested by its name, this approach estimates the DNAm age for each data set (considered as test data set) separately by fitting a separate multi-tissue age predictor to the remaining (left out) data sets. The resulting unbiased estimates of predictive accuracy can be found in Additional file 1: columns 'Cor LOOCV' and 'Error LOOCV', respectively.

Data sets differ greatly with respect to the median chronological age and the standard deviation, which is defined as the square root of the variance of age. Some data sets involve samples with the same age (standard deviation = 0) while others involve both young and old subjects (Additional file 1). As expected, the standard deviation is significantly correlated (r = 0.49, P = 4E-5; Figure 3A) with the corresponding LOOCV estimate of the age correlation. In contrast, the size of the data set has no significant relationship with the age correlation (Figure 3B).

A host of technical artifacts could explain differences in predictive accuracy: for example, variations in sample processing, DNA extraction, DNA storage effects, batch effects, and chip effects.

DNAm age of multiple tissues from the same subject:
In the following, I will address whether DNAm age differs substantially from chronological age. As a first step, I compared the mean DNAm age per tissue with the corresponding mean chronological age. As expected, mean DNAm age per tissue is highly correlated (cor = 0.99; Figure 3C) with the mean chronological age. But breast tissue shows evidence of significant age acceleration. The results of Figure 3C should be interpreted with caution because the analysis included training data sets and involved tissue samples from different subjects.

A more interesting analysis is to compare the DNAm ages of tissues collected from the same subjects. DNAm age does not change significantly across different brain regions (temporal cortex, pons, frontal cortex, cerebellum) from the same subjects (Additional file 5K,L). I could only find three human subjects from whom many tissues had been profiled (Figure 3E-G). Although the...`,
        figures: [
          {
            id: 'fig-2',
            title: 'Figure 2',
            caption: 'Chronological age (y-axis) versus DNAm age (x-axis) across 20 distinct tissue datasets. High linear correlation is maintained across diverse human tissues.',
            type: 'scatter',
          }
        ]
      },
      {
        pageNumber: 5,
        headerText: 'Horvath Genome Biology, 14:R115 http://genomebiology.com/14/10/R115',
        footerText: 'Page 5 of 19',
        text: `Heritability analysis of age acceleration in twins
To elucidate whether inter-individual variations in age acceleration (the residual between DNAm age and chronological age) reflect genetic determinism or environmental stochasticity, I analyzed two distinct twin cohorts: a newborn twin cohort (GSE36642) and an older adult twin cohort (GSE27317).

Heritability of age acceleration was estimated in two twin cohorts using Falconer's formula H² = 2(cor(MZ) – cor(DZ)). Broad-sense heritability was 100% in newborns and 39% in older adults, with MZ correlations (0.77 newborns, 0.40 older) far exceeding DZ correlations (−0.21 and 0.20).

This supports the epigenetic maintenance system (EMS) model in two ways:

1. The near-total genetic control in newborns implies that the EMS's "tick rate" during development is set by inherited machinery (e.g., maintenance methyltransferases DNMT1, DNMT3A, DNMT3B, and TET family demethylases), consistent with Horvath's claim that high power is required to maintain epigenetic stability during early morphogenesis.

2. The decline of heritability from 100% in neonates to 39% in middle-aged and older adults highlights cumulative environmental divergence and imperfect repair over the lifespan. As organisms age, stochastic molecular lesions, DNA replication errors, oxidative stressors, and imperfect enzymatic fidelity erode epigenetic fidelity, leading to progressive drift in methylation.`
      },
      {
        pageNumber: 6,
        headerText: 'Horvath Genome Biology, 14:R115 http://genomebiology.com/14/10/R115',
        footerText: 'Page 6 of 19',
        text: `Biological significance of the Epigenetic Maintenance System (EMS)
The mathematical constancy of the clock across multiple organs points toward an overarching biological process: the Epigenetic Maintenance System (EMS). We hypothesize that the 353 CpG sites serve as an internal read-out or molecular footprint of the effort expended by cellular maintenance machinery to maintain chromatin order against thermodynamic entropy.

Under this hypothesis, age acceleration in progeroid syndromes (Werner syndrome, Hutchinson-Gilford progeria) reflects premature exhaustion of the EMS. Conversely, somatic reprogramming via Yamanaka factors restores the EMS to its unburdened ground state.`
      }
    ]
  },
  {
    id: 'paper-senolytics-2020',
    title: 'Senolytics: Translating senescent cell clearance into clinical interventions',
    shortTitle: 'Senolytics',
    authors: ['James L. Kirkland', 'Tamara Tchkonia'],
    year: 2020,
    journalOrConference: 'Nature Medicine 26, 1199–1206',
    doi: '10.1038/s41591-020-0922-9',
    citationsCount: 1840,
    abstract: 'Cellular senescence is a state of irreversible cell-cycle arrest accompanied by the senescence-associated secretory phenotype (SASP). Here we review preclinical discoveries and clinical translation of senolytics—agents that selectively induce apoptosis in senescent cells—including Dasatinib plus Quercetin (D+Q) and Fisetin.',
    totalPages: 14,
    fileType: 'pdf',
    fileName: 'kirkland_nature_medicine_2020.pdf',
    fileSize: '2.8 MB',
    folderId: 'f-senolytics',
    collection: 'Senolytics',
    tags: ['Senescence', 'Senolytics', 'SASP', 'Geroscience'],
    createdAt: Date.now() - 86400000 * 25,
    bibtex: `@article{kirkland2020senolytics,
  title={Senolytics: Translating senescent cell clearance into clinical interventions},
  author={Kirkland, James L and Tchkonia, Tamara},
  journal={Nature Medicine},
  volume={26},
  number={8},
  pages={1199--1206},
  year={2020},
  publisher={Nature Publishing Group}
}`,
    pages: [
      {
        pageNumber: 1,
        headerText: 'Kirkland & Tchkonia Nature Medicine (2020) 26:1199–1206',
        footerText: 'Page 1 of 14',
        text: `Senolytics: Translating senescent cell clearance into clinical interventions
James L. Kirkland and Tamara Tchkonia*

Abstract
The accumulation of senescent cells in tissues contributes to diverse age-related chronic diseases, frailty, and physical resilience deficits. Senescent cells survive by upregulating Senescent Cell Anti-Apoptotic Pathways (SCAPs). Senolytic drugs transiently disable SCAP networks, allowing senescent cells to undergo apoptosis while preserving non-senescent bystander cells. In preclinical rodent models, intermittent dosing of Dasatinib and Quercetin or Fisetin extends remaining median lifespan by 36% and improves cardiovascular, metabolic, and pulmonary phenotypes.`
      },
      {
        pageNumber: 2,
        headerText: 'Kirkland & Tchkonia Nature Medicine (2020) 26:1199–1206',
        footerText: 'Page 2 of 14',
        text: `Mechanisms of SCAP dependence
Senescent cells resist physiological pro-apoptotic signals despite massive DNA damage response (DDR) signaling and mitochondrial dysfunction. By utilizing BCL-2/BCL-xL/BCL-w, PI3K/AKT, p53/p21, and serpin pathways, senescent cells evade apoptosis. Dasatinib targets SRC kinase and downstream ephrin signaling, whereas Quercetin and Fisetin inhibit BCL-2 family members and HIF-1α.
Importantly, because senolytics need only be administered intermittently ('hit-and-run' dosing), systemic side effects typical of continuous pharmacological blockade are minimized.`
      },
      {
        pageNumber: 3,
        headerText: 'Kirkland & Tchkonia Nature Medicine (2020) 26:1199–1206',
        footerText: 'Page 3 of 14',
        text: `Early human clinical trials
In a first-in-human pilot study in patients with idiopathic pulmonary fibrosis (IPF), intermittent oral D+Q treatment for three weeks produced statistically significant improvements in physical function, including 6-minute walking distance (+21.5 m) and 4-meter gait speed. In patients with diabetic kidney disease, an initial course of D+Q significantly reduced epidermal p16INK4a and p21 positive cells, as well as circulating pro-inflammatory SASP cytokines (IL-6, MMP-9, and MCP-1).`
      }
    ]
  },
  {
    id: 'paper-yamanaka-2006',
    title: 'Induction of Pluripotent Stem Cells from Mouse Embryonic and Adult Fibroblast Cultures by Defined Factors',
    shortTitle: 'Yamanaka Factors',
    authors: ['Kazutoshi Takahashi', 'Shinya Yamanaka'],
    year: 2006,
    journalOrConference: 'Cell 126, 663–676',
    doi: '10.1016/j.cell.2006.07.024',
    citationsCount: 16800,
    abstract: 'Differentiated cells were believed to be locked into terminal fates. Here, we demonstrate that somatic cells can be reprogrammed to pluripotency through the retroviral introduction of four transcription factors: Oct3/4, Sox2, Klf4, and c-Myc (OSKM). The resulting induced pluripotent stem cells (iPSCs) exhibit ES cell morphology, growth properties, and teratoma-forming pluripotency.',
    totalPages: 12,
    fileType: 'pdf',
    fileName: 'takahashi_yamanaka_cell_2006.pdf',
    fileSize: '3.1 MB',
    folderId: 'f-oskm',
    collection: 'Foundational OSKM discovery',
    tags: ['Reprogramming', 'Stem Cells', 'Yamanaka Factors', 'Pluripotency'],
    createdAt: Date.now() - 86400000 * 40,
    bibtex: `@article{takahashi2006induction,
  title={Induction of pluripotent stem cells from mouse embryonic and adult fibroblast cultures by defined factors},
  author={Takahashi, Kazutoshi and Yamanaka, Shinya},
  journal={Cell},
  volume={126},
  number={4},
  pages={663--676},
  year={2006},
  publisher={Elsevier}
}`,
    pages: [
      {
        pageNumber: 1,
        headerText: 'Takahashi & Yamanaka / Cell 126, 663–676, August 25, 2006',
        footerText: 'Page 1 of 12',
        text: `Induction of Pluripotent Stem Cells from Mouse Embryonic and Adult Fibroblast Cultures by Defined Factors
Kazutoshi Takahashi and Shinya Yamanaka*

Summary
Differentiated cells can be reprogrammed to an embryonic-like state by transfer of nuclear contents into oocytes or by fusion with ES cells. Little is known about the factors that induce this reprogramming. We hypothesized that factors that play critical roles in ES cell identity also initiate reprogramming. We evaluated 24 candidate genes and discovered that four factors—Oct3/4, Sox2, Klf4, and c-Myc—are sufficient to generate induced pluripotent stem cells (iPSCs) from embryonic and adult fibroblasts.`
      },
      {
        pageNumber: 2,
        headerText: 'Takahashi & Yamanaka / Cell 126, 663–676, August 25, 2006',
        footerText: 'Page 2 of 12',
        text: `Screening of Candidate Genes
We engineered an Fbx15 reporter locus with a beta-geo cassette. Fbx15 is expressed specifically in pluripotent stem cells. When individual factors were expressed alone, no G418-resistant colonies emerged. However, combining all 24 factors gave rise to drug-resistant colonies. Systematic withdrawal of individual factors identified four essential factors: Oct3/4, Sox2, Klf4, and c-Myc.
Omission of any one of these four factors led to a drastic reduction in colony count or complete loss of pluripotency.`
      }
    ]
  },
  {
    id: 'paper-attention-2017',
    title: 'Attention Is All You Need',
    shortTitle: 'Attention Is All...',
    authors: ['Ashish Vaswani', 'Noam Shazeer', 'Niki Parmar', 'Jakob Uszkoreit', 'Llion Jones', 'Aidan N. Gomez', 'Lukasz Kaiser', 'Illia Polosukhin'],
    year: 2017,
    journalOrConference: 'NeurIPS 2017',
    doi: '10.48550/arXiv.1706.03762',
    citationsCount: 142000,
    abstract: 'The dominant sequence transduction models are based on complex recurrent or convolutional neural networks. We propose the Transformer, a novel network architecture based solely on attention mechanisms, dispensing with recurrence and convolutions entirely.',
    totalPages: 11,
    fileType: 'pdf',
    fileName: 'attention_is_all_you_need.pdf',
    fileSize: '2.1 MB',
    folderId: 'f-multiomic',
    collection: 'Multi-omic biological age',
    tags: ['Machine Learning', 'Transformers', 'Attention', 'NLP'],
    createdAt: Date.now() - 86400000 * 50,
    bibtex: `@article{vaswani2017attention,
  title={Attention is all you need},
  author={Vaswani, Ashish and Shazeer, Noam and Parmar, Niki and Uszkoreit, Jakob and Jones, Llion and Gomez, Aidan N and Kaiser, {\\L}ukasz and Polosukhin, Illia},
  journal={Advances in Neural Information Processing Systems},
  volume={30},
  year={2017}
}`,
    pages: [
      {
        pageNumber: 1,
        headerText: '31st Conference on Neural Information Processing Systems (NeurIPS 2017), Long Beach, CA, USA.',
        footerText: 'Page 1 of 11',
        text: `Attention Is All You Need
Ashish Vaswani*, Noam Shazeer*, Niki Parmar*, Jakob Uszkoreit*, Llion Jones*, Aidan N. Gomez*, Łukasz Kaiser*, Illia Polosukhin*
Google Brain / Google Research / University of Toronto

Abstract
The dominant sequence transduction models are based on complex recurrent or convolutional neural networks in an encoder-decoder configuration. The Transformer model architecture eschews recurrence and instead relies entirely on an attention mechanism to draw global dependencies between input and output. The Transformer allows for significantly more parallelization and can reach a new state of the art in translation quality after being trained for as little as twelve hours on eight P100 GPUs.`
      }
    ]
  }
];

export const initialNotes = [
  {
    id: 'note-1',
    docId: 'paper-horvath-2013',
    title: 'Twin Heritability & EMS Notes',
    content: `### Horvath Clock Heritability Findings
- Newborn broad-sense heritability H² = 100% (MZ corr = 0.77, DZ corr = -0.21).
- Older adult heritability drops to 39% (MZ corr = 0.40, DZ corr = 0.20).
- Supports the Epigenetic Maintenance System (EMS) hypothesis:
  1. Developmental tick rate governed by genetic methylation machinery.
  2. Lifelong divergence driven by environmental exposures and stochastic enzymatic failure.`,
    tags: ['Heritability', 'EMS', 'Key Takeaways'],
    createdAt: Date.now() - 86400000 * 2,
    updatedAt: Date.now() - 3600000 * 4,
    linkedCitations: [
      {
        id: 1,
        docId: 'paper-horvath-2013',
        docTitle: 'DNA methylation age of human tissues and cell types',
        pageNumber: 5,
        passageText: 'Heritability of age acceleration was estimated in two twin cohorts using Falconers formula H² = 2(cor(MZ) – cor(DZ)).',
      }
    ]
  }
];
