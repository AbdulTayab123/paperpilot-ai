import * as pdfjsLib from 'pdfjs-dist';
import { DocumentPage, PaperDocument, EvidenceCitation } from '../types';

// Setup pdfjs worker
if (typeof window !== 'undefined' && pdfjsLib.GlobalWorkerOptions) {
  pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version || '4.10.38'}/pdf.worker.min.mjs`;
}

/**
 * Extracts text and metadata page-by-page from an uploaded PDF File
 */
export async function parsePdfFile(file: File): Promise<PaperDocument> {
  const arrayBuffer = await file.arrayBuffer();
  const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
  const pdfDoc = await loadingTask.promise;
  const numPages = pdfDoc.numPages;

  const pages: DocumentPage[] = [];
  let totalCharacters = 0;
  let firstPageText = '';

  for (let i = 1; i <= numPages; i++) {
    const page = await pdfDoc.getPage(i);
    const textContent = await page.getTextContent();
    const pageStrings = textContent.items
      .map((item: any) => ('str' in item ? item.str : ''))
      .filter((s: string) => s.trim().length > 0);

    const pageText = pageStrings.join(' ');
    totalCharacters += pageText.length;
    if (i === 1) firstPageText = pageText;

    pages.push({
      pageNumber: i,
      text: pageText,
      headerText: `${file.name.replace('.pdf', '')} — Page ${i} of ${numPages}`,
      footerText: `Page ${i} of ${numPages}`,
    });
  }

  // Check if it is a scanned PDF (image-only, virtually no selectable text)
  const isScanned = totalCharacters < 50 && numPages > 0;

  // Extract preliminary title & abstract heuristics
  const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
  let inferredTitle = cleanName;
  let inferredAbstract = 'No abstract detected in first page.';

  if (!isScanned && firstPageText.length > 50) {
    const lines = firstPageText.split('\n').map(l => l.trim()).filter(Boolean);
    if (lines.length > 0 && lines[0].length < 150) {
      inferredTitle = lines[0];
    }
    const abstractMatch = firstPageText.match(/abstract[:\s]+([\s\S]{100,600})/i);
    if (abstractMatch) {
      inferredAbstract = abstractMatch[1].trim() + '...';
    }
  }

  const paper: PaperDocument = {
    id: `doc-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
    title: inferredTitle,
    shortTitle: inferredTitle.length > 18 ? inferredTitle.substring(0, 15) + '...' : inferredTitle,
    authors: ['Extracted Author'],
    year: new Date().getFullYear(),
    journalOrConference: 'Uploaded Document',
    abstract: inferredAbstract,
    totalPages: numPages,
    fileType: 'pdf',
    fileName: file.name,
    fileSize: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
    pages,
    collection: 'User Uploads',
    tags: ['Uploaded', 'PDF'],
    isScanned,
    needsOcr: isScanned,
    createdAt: Date.now(),
  };

  return paper;
}

/**
 * Parses a plain text (.txt) research paper
 */
export async function parseTxtFile(file: File): Promise<PaperDocument> {
  const text = await file.text();
  const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');

  // Split text into ~500 word pages to maintain traceable page numbers
  const words = text.split(/\s+/);
  const wordsPerPage = 450;
  const numPages = Math.max(1, Math.ceil(words.length / wordsPerPage));
  const pages: DocumentPage[] = [];

  for (let i = 0; i < numPages; i++) {
    const pageWords = words.slice(i * wordsPerPage, (i + 1) * wordsPerPage);
    const pageText = pageWords.join(' ');
    pages.push({
      pageNumber: i + 1,
      text: pageText,
      headerText: `${cleanName} — Page ${i + 1} of ${numPages}`,
      footerText: `Page ${i + 1} of ${numPages}`,
    });
  }

  const paper: PaperDocument = {
    id: `doc-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
    title: cleanName,
    shortTitle: cleanName.length > 18 ? cleanName.substring(0, 15) + '...' : cleanName,
    authors: ['Local Researcher'],
    year: new Date().getFullYear(),
    journalOrConference: 'Text Document',
    abstract: text.substring(0, 300) + '...',
    totalPages: numPages,
    fileType: 'txt',
    fileName: file.name,
    fileSize: `${(file.size / 1024).toFixed(1)} KB`,
    pages,
    collection: 'User Uploads',
    tags: ['Uploaded', 'Text'],
    isScanned: false,
    needsOcr: false,
    createdAt: Date.now(),
  };

  return paper;
}

/**
 * Chunking and passage retrieval engine
 * Searches active documents for relevant sections matching the user's question
 */
export function retrievePassages(
  question: string,
  papers: PaperDocument[],
  maxPassages = 5
): EvidenceCitation[] {
  const queryTerms = question
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter(t => t.length > 2 && !['what', 'when', 'where', 'which', 'how', 'does', 'the', 'and', 'for', 'with', 'this', 'that', 'short', 'response'].includes(t));

  const candidates: {
    docId: string;
    docTitle: string;
    pageNumber: number;
    passageText: string;
    score: number;
    highlightText?: string;
  }[] = [];

  papers.forEach(paper => {
    paper.pages.forEach(page => {
      // Split page into paragraphs/sections
      const paragraphs = page.text
        .split(/(?:\r?\n){2,}|(?<=[.!?])\s+(?=[A-Z0-9])/)
        .map(p => p.trim())
        .filter(p => p.length > 40);

      paragraphs.forEach(para => {
        const lowerPara = para.toLowerCase();
        let score = 0;
        let matchedTerms = 0;

        queryTerms.forEach(term => {
          if (lowerPara.includes(term)) {
            matchedTerms++;
            // exact match bonus
            const occurrences = (lowerPara.match(new RegExp(`\\b${term}\\b`, 'g')) || []).length;
            score += 2 + occurrences;
          }
        });

        // Boost if multiple unique query keywords appear together
        if (matchedTerms > 1) {
          score += matchedTerms * 3;
        }

        if (score > 0) {
          candidates.push({
            docId: paper.id,
            docTitle: paper.title,
            pageNumber: page.pageNumber,
            passageText: para,
            score,
            highlightText: queryTerms[0] || '',
          });
        }
      });
    });
  });

  // Sort by relevance score
  candidates.sort((a, b) => b.score - a.score);

  // Return top N uniquely indexed citations
  return candidates.slice(0, maxPassages).map((c, index) => ({
    id: index + 1,
    docId: c.docId,
    docTitle: c.docTitle,
    pageNumber: c.pageNumber,
    passageText: c.passageText,
    highlightText: c.highlightText,
  }));
}
