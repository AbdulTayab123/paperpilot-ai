import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { DocumentReader } from './components/DocumentReader';
import { RightWorkspace } from './components/RightWorkspace';
import { UploadModal } from './components/UploadModal';
import { LibraryModal } from './components/LibraryModal';
import { IntegrityModal } from './components/IntegrityModal';
import { sampleFolders, samplePapers, initialNotes } from './data/samplePapers';
import { retrievePassages } from './utils/documentProcessor';
import {
  PaperDocument,
  FolderItem,
  ChatMessage,
  EvidenceCitation,
  ResearchNote,
  ComparisonMatrixRow,
  ResearchGapItem,
} from './types';

export default function App() {
  // Papers state
  const [papers, setPapers] = useState<PaperDocument[]>(() => {
    const saved = localStorage.getItem('paperpilot_papers');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return samplePapers;
  });

  // Folders state
  const [folders, setFolders] = useState<FolderItem[]>(() => {
    const saved = localStorage.getItem('paperpilot_folders');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return sampleFolders;
  });

  // Open Document Tabs (matching screenshot: DNA methylation & Senolytics)
  const [openPaperIds, setOpenPaperIds] = useState<string[]>([
    'paper-horvath-2013',
    'paper-senolytics-2020',
  ]);
  const [activePaperId, setActivePaperId] = useState<string>('paper-horvath-2013');

  // Workspaces
  const [workspaces, setWorkspaces] = useState<string[]>([
    'InGen Demo',
    'Longevity & Epigenetics Lab',
    'Graduate Thesis 2026',
  ]);
  const [activeWorkspace, setActiveWorkspace] = useState<string>('InGen Demo');

  // Sidebar sub-tab: 'files' | 'chats'
  const [activeSidebarTab, setActiveSidebarTab] = useState<'files' | 'chats'>('files');

  // Right AI Panel collapse toggle
  const [isRightPanelOpen, setIsRightPanelOpen] = useState(true);

  // Modals state
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [isLibraryOpen, setIsLibraryOpen] = useState(false);
  const [isIntegrityOpen, setIsIntegrityOpen] = useState(false);

  // Active highlighted citation for jumping to PDF page
  const [highlightedCitation, setHighlightedCitation] = useState<{
    docId: string;
    pageNumber: number;
    text?: string;
  } | null>({
    docId: 'paper-horvath-2013',
    pageNumber: 5,
    text: "Heritability of age acceleration was estimated in two twin cohorts using Falconer's formula",
  });

  // Initial Chat Conversation matching screenshot exactly!
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-user-1',
      sender: 'user',
      text: 'How does heritability analysis of age acceleration in twins support the epigenetic maintenance system model? Short response',
      timestamp: Date.now() - 120000,
    },
    {
      id: 'msg-asst-1',
      sender: 'assistant',
      thoughtSteps: 'Thought and read docs 2 steps',
      text: `Heritability of age acceleration was estimated in two twin cohorts using Falconer's formula H² = 2(cor(MZ) – cor(DZ)). Broad-sense heritability was 100% in newborns and 39% in older adults, with MZ correlations (0.77 newborns, 0.40 older) far exceeding DZ correlations (−0.21 and 0.20). [1] [2]

This supports the epigenetic maintenance system (EMS) model in two ways:

The near-total genetic control in newborns implies that the EMS's "tick rate" during development is set by inherited machinery (e.g., maintenance methyltransferases), consistent with Horvath's claim that high power is required to maintain epigenetic stability during...`,
      citations: [
        {
          id: 1,
          docId: 'paper-horvath-2013',
          docTitle: 'DNA methylation age of human tissues and cell types',
          pageNumber: 5,
          passageText:
            "Heritability of age acceleration was estimated in two twin cohorts using Falconer's formula H² = 2(cor(MZ) – cor(DZ)). Broad-sense heritability was 100% in newborns and 39% in older adults, with MZ correlations (0.77 newborns, 0.40 older) far exceeding DZ correlations (−0.21 and 0.20).",
        },
        {
          id: 2,
          docId: 'paper-horvath-2013',
          docTitle: 'DNA methylation age of human tissues and cell types',
          pageNumber: 5,
          passageText:
            "This supports the epigenetic maintenance system (EMS) model in two ways: The near-total genetic control in newborns implies that the EMS's 'tick rate' during development is set by inherited machinery... while the decline of heritability to 39% in older adults reflects cumulative environmental divergence.",
        },
      ],
      sourceDocs: [
        {
          id: 'paper-horvath-2013',
          title: 'DNA methylation age of human tissues and cell types',
          pages: [4, 5],
        },
      ],
      timestamp: Date.now() - 60000,
    },
  ]);

  const [isLoadingAI, setIsLoadingAI] = useState(false);

  // Notes state
  const [notes, setNotes] = useState<ResearchNote[]>(initialNotes);

  // Preloaded Comparative Analysis Matrix across Horvath and Kirkland papers
  const [comparisonMatrix, setComparisonMatrix] = useState<ComparisonMatrixRow[]>([
    {
      dimension: 'Research Objectives',
      findings: [
        {
          docId: 'paper-horvath-2013',
          docTitle: 'Horvath (2013)',
          content: 'Develop a pan-tissue molecular clock measuring chronological age and biological age acceleration across all human organ types.',
          citedPage: 1,
        },
        {
          docId: 'paper-senolytics-2020',
          docTitle: 'Kirkland (2020)',
          content: 'Identify pharmacological agents that selectively eliminate senescent cells via SCAP inhibition to extend healthspan.',
          citedPage: 1,
        },
      ],
    },
    {
      dimension: 'Methodology & Approach',
      findings: [
        {
          docId: 'paper-horvath-2013',
          docTitle: 'Horvath (2013)',
          content: 'Elastic net penalized regression across 8,000 Illumina DNA methylation arrays from 51 healthy tissues to isolate 353 CpG dinucleotides.',
          citedPage: 2,
        },
        {
          docId: 'paper-senolytics-2020',
          docTitle: 'Kirkland (2020)',
          content: 'Intermittent ("hit-and-run") dosing of small molecules Dasatinib + Quercetin targeting SCAPs and BCL-2 anti-apoptotic cascades.',
          citedPage: 2,
        },
      ],
    },
    {
      dimension: 'Datasets & Cohorts',
      findings: [
        {
          docId: 'paper-horvath-2013',
          docTitle: 'Horvath (2013)',
          content: '39 public Illumina HumanMethylation27/450 array datasets, including twin cohorts GSE36642 and GSE27317.',
          citedPage: 4,
        },
        {
          docId: 'paper-senolytics-2020',
          docTitle: 'Kirkland (2020)',
          content: 'Preclinical murine aging cohorts and human Phase 1 pilot trials in IPF and diabetic kidney disease.',
          citedPage: 3,
        },
      ],
    },
    {
      dimension: 'Key Results & Findings',
      findings: [
        {
          docId: 'paper-horvath-2013',
          docTitle: 'Horvath (2013)',
          content: 'Pan-tissue Pearson correlation r = 0.96 with chronological age; newborn heritability H² = 100%, declining to 39% in older adults.',
          citedPage: 4,
        },
        {
          docId: 'paper-senolytics-2020',
          docTitle: 'Kirkland (2020)',
          content: '36% increase in remaining median rodent lifespan; significant reduction in p16/p21 positive cells and circulating SASP cytokines.',
          citedPage: 1,
        },
      ],
    },
    {
      dimension: 'Stated Limitations',
      findings: [
        {
          docId: 'paper-horvath-2013',
          docTitle: 'Horvath (2013)',
          content: 'Predictive accuracy affected by sample processing variance, chip batch effects, and high breast tissue age acceleration.',
          citedPage: 4,
        },
        {
          docId: 'paper-senolytics-2020',
          docTitle: 'Kirkland (2020)',
          content: 'Potential off-target cytotoxicity during wound healing; limited long-term human safety trials.',
          isNotStated: false,
        },
      ],
    },
    {
      dimension: 'Future Work',
      findings: [
        {
          docId: 'paper-horvath-2013',
          docTitle: 'Horvath (2013)',
          content: 'Investigate whether reversing DNAm age via stem cell reprogramming or epigenetic rejuvenation prolongs functional organismal lifespan.',
          citedPage: 6,
        },
        {
          docId: 'paper-senolytics-2020',
          docTitle: 'Kirkland (2020)',
          content: 'Double-blind randomized clinical trials for specific geriatric multimorbidities and Alzheimer\'s disease.',
        },
      ],
    },
  ]);

  const [isLoadingComparison, setIsLoadingComparison] = useState(false);

  // Preloaded Research Gaps
  const [researchGaps, setResearchGaps] = useState<ResearchGapItem[]>([
    {
      gapTitle: 'Epigenetic Clock Decoupling in Senolytic Clearance',
      category: 'Empirical',
      observation:
        'Horvath (2013) demonstrates that DNA methylation age reflects an autonomous maintenance tick rate, whereas Kirkland (2020) demonstrates senescent cell clearance via D+Q.',
      hypothesis:
        'Hypothesis requiring literature verification: Does senolytic elimination of SASP-secreting cells arrest or actively reverse the 353-CpG pan-tissue Horvath clock, or does the epigenetic clock measure an orthogonal biological aging axis independent of cellular senescence?',
      suggestedStudy:
        'Quantify Horvath and GrimAge acceleration in longitudinal human cohorts before and after intermittent D+Q administration.',
    },
    {
      gapTitle: 'Tissue-Specific Discordance in Epigenetic Rejuvenation',
      category: 'Theoretical',
      observation:
        'Horvath identified substantial unexplained age acceleration in breast tissue (cor = 0.87 vs 0.96 average) despite uniform systemic blood aging.',
      hypothesis:
        'Hypothesis requiring literature verification: Local microenvironmental endocrine signaling or parenchymal mitotic turnover rate alters epigenetic maintenance fidelity independent of whole-body chronological age.',
      suggestedStudy:
        'Single-cell methylome profiling of primary epithelial versus stromal compartments under controlled hormone exposure.',
    },
  ]);
  const [isLoadingGaps, setIsLoadingGaps] = useState(false);

  // Persist papers and folders to local storage
  useEffect(() => {
    localStorage.setItem('paperpilot_papers', JSON.stringify(papers));
  }, [papers]);

  useEffect(() => {
    localStorage.setItem('paperpilot_folders', JSON.stringify(folders));
  }, [folders]);

  // Handle switching active paper
  const handleSelectPaper = (paperId: string) => {
    if (!openPaperIds.includes(paperId)) {
      setOpenPaperIds([...openPaperIds, paperId]);
    }
    setActivePaperId(paperId);
  };

  // Handle closing a document tab
  const handleClosePaperTab = (paperId: string) => {
    const nextTabs = openPaperIds.filter(id => id !== paperId);
    setOpenPaperIds(nextTabs);
    if (activePaperId === paperId) {
      if (nextTabs.length > 0) {
        setActivePaperId(nextTabs[nextTabs.length - 1]);
      } else {
        setActivePaperId('');
      }
    }
  };

  // Handle citation click: jump to document & page
  const handleCitationClick = (citation: EvidenceCitation) => {
    if (!openPaperIds.includes(citation.docId)) {
      setOpenPaperIds([...openPaperIds, citation.docId]);
    }
    setActivePaperId(citation.docId);
    setHighlightedCitation({
      docId: citation.docId,
      pageNumber: citation.pageNumber,
      text: citation.passageText,
    });
  };

  // Handle user sending an AI Q&A query
  const handleSendMessage = async (text: string, model: string) => {
    const userMsg: ChatMessage = {
      id: `msg-user-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: Date.now(),
    };

    setMessages(prev => [...prev, userMsg]);
    setIsLoadingAI(true);

    try {
      // 1. Retrieve grounded evidence passages from active papers
      const activeDocs = papers.filter(p => openPaperIds.includes(p.id) || p.id === activePaperId);
      const passages = retrievePassages(text, activeDocs.length > 0 ? activeDocs : papers, 4);

      // 2. Call server endpoint
      const response = await fetch('/api/research/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: text,
          passages,
          documents: activeDocs.map(d => ({ id: d.id, title: d.title })),
          model: model.includes('3.1') ? 'gemini-3.1-pro-preview' : 'gemini-3.8-flash',
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Server responded with ${response.status}`);
      }

      const data = await response.json();

      const assistantMsg: ChatMessage = {
        id: `msg-asst-${Date.now()}`,
        sender: 'assistant',
        text: data.answer,
        thoughtSteps: data.thoughtSteps || 'Thought and read docs 2 steps',
        citations: passages,
        sourceDocs: activeDocs.map(d => ({ id: d.id, title: d.title, pages: [1, 2] })),
        timestamp: Date.now(),
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (err: any) {
      console.error(err);
      // Transparent error display per user instructions
      const errorMsg: ChatMessage = {
        id: `msg-error-${Date.now()}`,
        sender: 'assistant',
        text: `Inference failed: ${err.message || 'Unable to connect to research inference endpoint'}. Please check server connectivity or API key configuration.`,
        isError: true,
        timestamp: Date.now(),
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoadingAI(false);
    }
  };

  // Run paper comparison
  const handleRunComparison = async (selectedIds: string[]) => {
    const selectedPapers = papers.filter(p => selectedIds.includes(p.id));
    if (selectedPapers.length < 2) return;

    setIsLoadingComparison(true);
    try {
      const response = await fetch('/api/research/compare', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          papers: selectedPapers.map(p => ({
            id: p.id,
            title: p.title,
            authors: p.authors.join(', '),
            year: p.year,
            text: p.pages.map(pg => pg.text).join('\n'),
          })),
        }),
      });

      if (!response.ok) {
        throw new Error('Comparison API request failed');
      }

      const data = await response.json();
      if (data.comparisonMatrix && Array.isArray(data.comparisonMatrix)) {
        const rows: ComparisonMatrixRow[] = data.comparisonMatrix.map((item: any) => ({
          dimension: item.dimension,
          findings: item.findings.map((f: any) => ({
            docId: '',
            docTitle: f.paperTitle,
            content: f.content,
            isNotStated: f.content?.toLowerCase().includes('not stated'),
            citedPage: f.citedPage ? parseInt(f.citedPage, 10) : undefined,
          })),
        }));
        setComparisonMatrix(rows);
      }
    } catch (err) {
      console.error('Error generating comparison matrix:', err);
      alert('Comparison failed: ' + (err as Error).message);
    } finally {
      setIsLoadingComparison(false);
    }
  };

  // Run research gaps exploration
  const handleExploreGaps = async () => {
    setIsLoadingGaps(true);
    try {
      const response = await fetch('/api/research/gaps', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          papers: papers.slice(0, 3).map(p => ({
            title: p.title,
            text: p.pages.map(pg => pg.text).join('\n'),
          })),
        }),
      });

      if (!response.ok) {
        throw new Error('Gaps exploration request failed');
      }

      const data = await response.json();
      if (data.gaps && Array.isArray(data.gaps)) {
        setResearchGaps(data.gaps);
      }
    } catch (err) {
      console.error('Error exploring research gaps:', err);
      alert('Gap exploration error: ' + (err as Error).message);
    } finally {
      setIsLoadingGaps(false);
    }
  };

  // Handle uploaded paper
  const handlePaperUploaded = (newPaper: PaperDocument) => {
    setPapers(prev => [newPaper, ...prev]);
    if (!openPaperIds.includes(newPaper.id)) {
      setOpenPaperIds(prev => [...prev, newPaper.id]);
    }
    setActivePaperId(newPaper.id);
  };

  // Handle delete paper
  const handleDeletePaper = (paperId: string) => {
    setPapers(prev => prev.filter(p => p.id !== paperId));
    handleClosePaperTab(paperId);
  };

  // Handle create folder
  const handleAddFolder = (name: string, parentId: string | null) => {
    const newFolder: FolderItem = {
      id: `f-${Date.now()}`,
      name,
      parentId,
      isOpen: true,
    };
    setFolders(prev => [...prev, newFolder]);
  };

  // Active open papers objects
  const openPaperObjects = papers.filter(p => openPaperIds.includes(p.id));
  const activePaper = papers.find(p => p.id === activePaperId) || null;

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#F8F9FA] text-[#1F2328] font-sans antialiased">
      {/* 1. Left Sidebar Navigation Matching Screenshot */}
      <Sidebar
        folders={folders}
        papers={papers}
        activePaperId={activePaperId}
        onSelectPaper={handleSelectPaper}
        onOpenUpload={() => setIsUploadOpen(true)}
        onOpenLibrary={() => setIsLibraryOpen(true)}
        onOpenIntegrity={() => setIsIntegrityOpen(true)}
        activeSidebarTab={activeSidebarTab}
        setActiveSidebarTab={setActiveSidebarTab}
        onAddFolder={handleAddFolder}
        workspaces={workspaces}
        activeWorkspace={activeWorkspace}
        setActiveWorkspace={setActiveWorkspace}
      />

      {/* 2. Center Document / PDF Reader Area */}
      <main className="flex-1 flex flex-col h-full min-w-0 overflow-hidden relative">
        <DocumentReader
          openPapers={openPaperObjects}
          activePaperId={activePaperId}
          onSelectPaper={setActivePaperId}
          onClosePaperTab={handleClosePaperTab}
          onOpenUpload={() => setIsUploadOpen(true)}
          highlightedCitation={highlightedCitation}
          onAddNoteFromQuote={(quote, pageNumber, paperTitle) => {
            const newNote: ResearchNote = {
              id: `note-${Date.now()}`,
              docId: activePaperId,
              title: `Excerpt from ${paperTitle} (p.${pageNumber})`,
              content: `> "${quote}"\n\n*Source: ${paperTitle}, Page ${pageNumber}*`,
              tags: ['Excerpt', 'Quote'],
              createdAt: Date.now(),
              updatedAt: Date.now(),
            };
            setNotes(prev => [newNote, ...prev]);
            alert(`Quote from Page ${pageNumber} saved to Research Notes!`);
          }}
          isRightPanelOpen={isRightPanelOpen}
          onToggleRightPanel={() => setIsRightPanelOpen(!isRightPanelOpen)}
        />
      </main>

      {/* 3. Right Sidebar Workspace Matching Screenshot */}
      {isRightPanelOpen && (
        <RightWorkspace
          activePaper={activePaper}
          allPapers={papers}
          messages={messages}
          onSendMessage={handleSendMessage}
          isLoadingAI={isLoadingAI}
          onCitationClick={handleCitationClick}
          notes={notes}
          onSaveNote={note => {
            setNotes(prev => {
              const idx = prev.findIndex(n => n.id === note.id);
              if (idx >= 0) {
                const updated = [...prev];
                updated[idx] = note;
                return updated;
              }
              return [note, ...prev];
            });
          }}
          onDeleteNote={id => setNotes(prev => prev.filter(n => n.id !== id))}
          comparisonMatrix={comparisonMatrix}
          onRunComparison={handleRunComparison}
          researchGaps={researchGaps}
          onExploreGaps={handleExploreGaps}
          isLoadingGaps={isLoadingGaps}
          isLoadingComparison={isLoadingComparison}
          onSelectPaper={handleSelectPaper}
        />
      )}

      {/* Modals */}
      <UploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onPaperUploaded={handlePaperUploaded}
        folders={folders}
      />

      <LibraryModal
        isOpen={isLibraryOpen}
        onClose={() => setIsLibraryOpen(false)}
        papers={papers}
        onSelectPaper={handleSelectPaper}
        onDeletePaper={handleDeletePaper}
        onOpenUpload={() => setIsUploadOpen(true)}
        onStartComparison={ids => {
          handleRunComparison(ids);
          setIsRightPanelOpen(true);
        }}
      />

      <IntegrityModal
        isOpen={isIntegrityOpen}
        onClose={() => setIsIntegrityOpen(false)}
      />
    </div>
  );
}
