export interface DocumentPage {
  pageNumber: number;
  text: string;
  headerText?: string;
  footerText?: string;
  columns?: string[][]; // two columns of text for authentic layout
  figures?: {
    id: string;
    title: string;
    caption: string;
    type: 'scatter' | 'matrix' | 'flowchart' | 'bar';
    dataPoints?: any;
  }[];
}

export interface PaperDocument {
  id: string;
  title: string;
  shortTitle: string;
  authors: string[];
  year: number;
  journalOrConference: string;
  doi?: string;
  citationsCount?: number;
  abstract: string;
  totalPages: number;
  fileType: 'pdf' | 'txt';
  fileData?: ArrayBuffer | string; // Base64 or raw text
  fileName: string;
  fileSize: string;
  pages: DocumentPage[];
  folderId?: string;
  collection: string;
  tags: string[];
  isScanned?: boolean;
  needsOcr?: boolean;
  bibtex?: string;
  createdAt: number;
}

export interface FolderItem {
  id: string;
  name: string;
  parentId: string | null;
  children?: string[];
  isOpen?: boolean;
}

export interface EvidenceCitation {
  id: number;
  docId: string;
  docTitle: string;
  pageNumber: number;
  passageText: string;
  highlightText?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  thoughtSteps?: string;
  citations?: EvidenceCitation[];
  sourceDocs?: { id: string; title: string; pages: number[] }[];
  timestamp: number;
  isError?: boolean;
}

export interface ResearchNote {
  id: string;
  docId?: string;
  title: string;
  content: string;
  tags: string[];
  linkedCitations?: EvidenceCitation[];
  createdAt: number;
  updatedAt: number;
}

export interface ComparisonMatrixRow {
  dimension: string;
  findings: {
    docId: string;
    docTitle: string;
    content: string;
    isNotStated?: boolean;
    citedPage?: number;
  }[];
}

export interface ResearchGapItem {
  gapTitle: string;
  category: 'Methodological' | 'Empirical' | 'Population/Dataset' | 'Theoretical';
  observation: string;
  hypothesis: string;
  suggestedStudy: string;
}
