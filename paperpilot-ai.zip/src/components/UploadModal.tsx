import React, { useState, useRef } from 'react';
import {
  Upload,
  X,
  FileText,
  CheckCircle2,
  AlertTriangle,
  Loader2,
  Folder,
} from 'lucide-react';
import { parsePdfFile, parseTxtFile } from '../utils/documentProcessor';
import { FolderItem, PaperDocument } from '../types';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPaperUploaded: (paper: PaperDocument) => void;
  folders: FolderItem[];
}

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  onPaperUploaded,
  folders,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFolderId, setSelectedFolderId] = useState<string>('f-epigenetic');
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusMessage, setStatusMessage] = useState('');
  const [error, setError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleProcessFile = async (file: File) => {
    setError(null);
    setIsProcessing(true);
    setProgress(20);
    setStatusMessage(`Reading file buffer: ${file.name}...`);

    try {
      let paper: PaperDocument;

      if (file.type === 'application/pdf' || file.name.endsWith('.pdf')) {
        setProgress(45);
        setStatusMessage('Extracting pages & computing text layers via PDF.js...');
        paper = await parsePdfFile(file);
      } else if (file.type.includes('text') || file.name.endsWith('.txt')) {
        setProgress(50);
        setStatusMessage('Segmenting text into traceable academic pages...');
        paper = await parseTxtFile(file);
      } else {
        throw new Error('Unsupported format. Please upload a PDF or TXT research paper.');
      }

      paper.folderId = selectedFolderId;
      const targetFolder = folders.find(f => f.id === selectedFolderId);
      if (targetFolder) {
        paper.collection = targetFolder.name;
      }

      setProgress(85);
      setStatusMessage('Indexing chunk vectors and metadata...');
      await new Promise(r => setTimeout(r, 400));

      setProgress(100);
      setStatusMessage('Processing complete!');

      onPaperUploaded(paper);
      setTimeout(() => {
        setIsProcessing(false);
        setProgress(0);
        onClose();
      }, 500);
    } catch (err: any) {
      console.error(err);
      setError(err?.message || 'Failed to process document');
      setIsProcessing(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleProcessFile(e.dataTransfer.files[0]);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-xl shadow-2xl border border-gray-200 w-full max-w-lg overflow-hidden flex flex-col font-sans">
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
              <Upload className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-gray-900">Upload Research Document</h3>
              <p className="text-xs text-gray-500">PDF and TXT with page-level preservation</p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isProcessing}
            className="p-1.5 rounded-md hover:bg-gray-100 text-gray-400 hover:text-gray-700 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-4 text-xs">
          {/* Target Folder Selector */}
          <div>
            <label className="block font-semibold text-gray-700 mb-1">Target Collection / Folder</label>
            <div className="relative">
              <select
                value={selectedFolderId}
                onChange={e => setSelectedFolderId(e.target.value)}
                disabled={isProcessing}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 bg-white text-gray-800 outline-none focus:border-indigo-600"
              >
                {folders.map(f => (
                  <option key={f.id} value={f.id}>
                    {f.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Drag & Drop Area */}
          <div
            onDragOver={e => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${
              isDragging
                ? 'border-indigo-600 bg-indigo-50/50'
                : 'border-gray-300 hover:border-indigo-400 bg-gray-50/50'
            }`}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={e => {
                if (e.target.files && e.target.files[0]) {
                  handleProcessFile(e.target.files[0]);
                }
              }}
              accept=".pdf,.txt"
              className="hidden"
            />
            <div className="w-12 h-12 rounded-full bg-white shadow-xs border border-gray-200 flex items-center justify-center mx-auto text-indigo-600 mb-3">
              <Upload className="w-6 h-6" />
            </div>
            <div className="font-semibold text-gray-800 text-sm mb-1">
              Click to select or drag and drop paper
            </div>
            <p className="text-gray-500 text-[11px]">
              Supports standard scientific PDFs and TXT files. Original page numbers are preserved.
            </p>
          </div>

          {/* Upload Progress Bar */}
          {isProcessing && (
            <div className="p-3 bg-indigo-50/60 border border-indigo-100 rounded-lg space-y-2">
              <div className="flex justify-between items-center text-[11px] text-indigo-900 font-medium">
                <span className="flex items-center gap-1.5">
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-indigo-600" />
                  {statusMessage}
                </span>
                <span>{progress}%</span>
              </div>
              <div className="w-full h-1.5 bg-indigo-200/60 rounded-full overflow-hidden">
                <div
                  className="h-full bg-indigo-600 transition-all duration-300 rounded-full"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}

          {/* Error Message */}
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-800 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Research integrity notice */}
          <div className="p-2.5 bg-gray-50 border border-gray-200 rounded-lg text-[11px] text-gray-500 leading-normal">
            <strong>Security & Privacy:</strong> Document text is extracted client-side. Citations link exclusively to verified extracted pages. Embedded prompt injection attempts in papers are strictly neutralized.
          </div>
        </div>
      </div>
    </div>
  );
};
