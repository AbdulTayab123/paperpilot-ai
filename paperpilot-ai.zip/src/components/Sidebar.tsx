import React, { useState } from 'react';
import {
  ChevronDown,
  ChevronRight,
  Folder,
  FolderOpen,
  FileText,
  Plus,
  Home,
  BookOpen,
  Search,
  PenSquare,
  HelpCircle,
  Upload,
  CheckCircle2,
  Sparkles,
  Library,
  Layers,
  MessageSquare,
} from 'lucide-react';
import { FolderItem, PaperDocument } from '../types';

interface SidebarProps {
  folders: FolderItem[];
  papers: PaperDocument[];
  activePaperId: string | null;
  onSelectPaper: (paperId: string) => void;
  onOpenUpload: () => void;
  onOpenLibrary: () => void;
  onOpenIntegrity: () => void;
  activeSidebarTab: 'files' | 'chats';
  setActiveSidebarTab: (tab: 'files' | 'chats') => void;
  onAddFolder: (name: string, parentId: string | null) => void;
  workspaces: string[];
  activeWorkspace: string;
  setActiveWorkspace: (ws: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  folders,
  papers,
  activePaperId,
  onSelectPaper,
  onOpenUpload,
  onOpenLibrary,
  onOpenIntegrity,
  activeSidebarTab,
  setActiveSidebarTab,
  onAddFolder,
  workspaces,
  activeWorkspace,
  setActiveWorkspace,
}) => {
  const [openFolders, setOpenFolders] = useState<Record<string, boolean>>({
    'f-anti-aging': true,
    'f-yamanaka': true,
    'f-biomarkers': true,
    'f-biology': true,
  });

  const [isWorkspaceMenuOpen, setIsWorkspaceMenuOpen] = useState(false);
  const [newFolderInput, setNewFolderInput] = useState<{ open: boolean; parentId: string | null; name: string }>({
    open: false,
    parentId: null,
    name: '',
  });

  const toggleFolder = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setOpenFolders(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const rootFolders = folders.filter(f => f.parentId === null);

  const handleCreateFolder = (e: React.FormEvent) => {
    e.preventDefault();
    if (newFolderInput.name.trim()) {
      onAddFolder(newFolderInput.name.trim(), newFolderInput.parentId);
      setNewFolderInput({ open: false, parentId: null, name: '' });
    }
  };

  return (
    <aside className="w-64 h-full bg-[#FAFAFA] border-r border-[#E5E7EB] flex flex-col select-none shrink-0 text-[#1F2328] font-sans">
      {/* Workspace Selector */}
      <div className="p-3 border-b border-[#EAECEF] relative">
        <button
          onClick={() => setIsWorkspaceMenuOpen(!isWorkspaceMenuOpen)}
          className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-md hover:bg-gray-100 text-sm font-semibold text-[#1F2328] transition-colors"
        >
          <span className="truncate">{activeWorkspace}</span>
          <ChevronDown className="w-4 h-4 text-gray-500 ml-1 shrink-0" />
        </button>

        {isWorkspaceMenuOpen && (
          <div className="absolute top-12 left-3 right-3 bg-white border border-gray-200 rounded-lg shadow-lg z-50 py-1 text-xs">
            {workspaces.map(ws => (
              <button
                key={ws}
                onClick={() => {
                  setActiveWorkspace(ws);
                  setIsWorkspaceMenuOpen(false);
                }}
                className={`w-full text-left px-3 py-1.5 hover:bg-gray-50 flex items-center justify-between ${
                  activeWorkspace === ws ? 'font-semibold text-indigo-600 bg-indigo-50/50' : 'text-gray-700'
                }`}
              >
                <span>{ws}</span>
                {activeWorkspace === ws && <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />}
              </button>
            ))}
            <div className="border-t border-gray-100 my-1"></div>
            <button
              onClick={() => {
                const newName = prompt('Enter new workspace name:');
                if (newName) {
                  setActiveWorkspace(newName);
                }
                setIsWorkspaceMenuOpen(false);
              }}
              className="w-full text-left px-3 py-1.5 hover:bg-gray-50 text-indigo-600 font-medium flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" /> New Collection
            </button>
          </div>
        )}
      </div>

      {/* Primary Actions matching screenshot */}
      <div className="p-2 space-y-0.5 border-b border-[#EAECEF]">
        <button
          onClick={onOpenUpload}
          className="w-full flex items-center gap-2.5 px-3 py-1.5 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-100 transition-colors"
        >
          <PenSquare className="w-4 h-4 text-gray-600" />
          <span>Create</span>
        </button>
        <button
          onClick={onOpenLibrary}
          className="w-full flex items-center gap-2.5 px-3 py-1.5 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-100 transition-colors"
        >
          <Home className="w-4 h-4 text-gray-600" />
          <span>Home</span>
        </button>
        <button
          onClick={onOpenLibrary}
          className="w-full flex items-center gap-2.5 px-3 py-1.5 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-100 transition-colors"
        >
          <BookOpen className="w-4 h-4 text-gray-600" />
          <span>Library</span>
          <span className="ml-auto text-xs text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded font-mono">
            {papers.length}
          </span>
        </button>
        <button
          onClick={onOpenLibrary}
          className="w-full flex items-center gap-2.5 px-3 py-1.5 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-100 transition-colors"
        >
          <Search className="w-4 h-4 text-gray-600" />
          <span>Search</span>
        </button>
      </div>

      {/* Sub-tabs: Files | Chats */}
      <div className="px-3 pt-3 pb-1 flex items-center gap-4 text-xs font-semibold text-gray-600 border-b border-[#F0F2F5]">
        <button
          onClick={() => setActiveSidebarTab('files')}
          className={`pb-1.5 transition-colors relative ${
            activeSidebarTab === 'files' ? 'text-gray-900 font-bold' : 'text-gray-400 hover:text-gray-600'
          }`}
        >
          Files
          {activeSidebarTab === 'files' && (
            <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-gray-900 rounded-full" />
          )}
        </button>
        <button
          onClick={() => setActiveSidebarTab('chats')}
          className={`pb-1.5 transition-colors relative ${
            activeSidebarTab === 'chats' ? 'text-gray-900 font-bold' : 'text-gray-400 hover:text-gray-600'
          }`}
        >
          Chats
          {activeSidebarTab === 'chats' && (
            <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-gray-900 rounded-full" />
          )}
        </button>

        <button
          onClick={() => setNewFolderInput({ open: true, parentId: null, name: '' })}
          title="Create folder"
          className="ml-auto p-1 rounded hover:bg-gray-200 text-gray-400 hover:text-gray-700 transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Hierarchical Folder & File Tree */}
      <div className="flex-1 overflow-y-auto px-2 py-2 space-y-1 text-xs">
        {newFolderInput.open && (
          <form onSubmit={handleCreateFolder} className="p-1 mb-2 bg-white rounded border border-indigo-200 shadow-xs">
            <input
              type="text"
              placeholder="Folder name..."
              value={newFolderInput.name}
              onChange={e => setNewFolderInput({ ...newFolderInput, name: e.target.value })}
              autoFocus
              className="w-full text-xs px-2 py-1 border border-gray-200 rounded outline-none focus:border-indigo-500"
            />
            <div className="flex justify-end gap-1 mt-1">
              <button
                type="button"
                onClick={() => setNewFolderInput({ open: false, parentId: null, name: '' })}
                className="px-2 py-0.5 text-[10px] text-gray-500 hover:bg-gray-100 rounded"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-2 py-0.5 text-[10px] bg-indigo-600 text-white rounded font-medium"
              >
                Create
              </button>
            </div>
          </form>
        )}

        {rootFolders.map(root => {
          const isOpen = openFolders[root.id] ?? false;
          const subfolders = folders.filter(f => f.parentId === root.id);
          const rootPapers = papers.filter(p => p.folderId === root.id);

          return (
            <div key={root.id} className="space-y-0.5">
              {/* Root Folder Item */}
              <div
                onClick={e => toggleFolder(root.id, e)}
                className="flex items-center gap-1.5 px-2 py-1.5 rounded-md hover:bg-gray-100/80 cursor-pointer text-[#24292F] font-medium transition-colors"
              >
                {isOpen ? (
                  <FolderOpen className="w-4 h-4 text-gray-600 shrink-0" />
                ) : (
                  <Folder className="w-4 h-4 text-gray-600 shrink-0" />
                )}
                <span className="truncate">{root.name}</span>
              </div>

              {/* Subfolders & Papers */}
              {isOpen && (
                <div className="pl-4 space-y-0.5 border-l border-gray-200 ml-3">
                  {subfolders.length === 0 && rootPapers.length === 0 && (
                    <div className="px-2 py-1 text-[11px] text-gray-400 italic">No subfolders</div>
                  )}

                  {subfolders.map(sub => {
                    const subPapers = papers.filter(p => p.folderId === sub.id);
                    return (
                      <div key={sub.id}>
                        <div
                          onClick={() => {
                            if (subPapers.length > 0) {
                              onSelectPaper(subPapers[0].id);
                            }
                          }}
                          className={`flex items-center gap-1.5 px-2 py-1.5 rounded-md cursor-pointer transition-colors ${
                            subPapers.some(p => p.id === activePaperId)
                              ? 'bg-indigo-50/80 text-indigo-950 font-semibold'
                              : 'text-gray-700 hover:bg-gray-100'
                          }`}
                        >
                          <Folder className="w-3.5 h-3.5 text-gray-500 shrink-0" />
                          <span className="truncate">{sub.name}</span>
                          {subPapers.length > 0 && (
                            <span className="ml-auto text-[10px] text-gray-400 bg-white/80 border border-gray-200 px-1 rounded-sm">
                              {subPapers.length}
                            </span>
                          )}
                        </div>

                        {/* Papers within subfolder */}
                        {subPapers.map(paper => (
                          <div
                            key={paper.id}
                            onClick={() => onSelectPaper(paper.id)}
                            className={`flex items-center gap-1.5 pl-5 pr-2 py-1 rounded cursor-pointer text-[11px] transition-colors ${
                              paper.id === activePaperId
                                ? 'bg-indigo-100/70 text-indigo-900 font-semibold border-r-2 border-indigo-600'
                                : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                            }`}
                          >
                            <FileText className="w-3 h-3 text-gray-400 shrink-0" />
                            <span className="truncate">{paper.shortTitle || paper.title}</span>
                          </div>
                        ))}
                      </div>
                    );
                  })}

                  {/* Any papers directly under root folder */}
                  {rootPapers.map(paper => (
                    <div
                      key={paper.id}
                      onClick={() => onSelectPaper(paper.id)}
                      className={`flex items-center gap-1.5 px-2 py-1 rounded cursor-pointer text-[11px] transition-colors ${
                        paper.id === activePaperId
                          ? 'bg-indigo-100/70 text-indigo-900 font-semibold'
                          : 'text-gray-600 hover:bg-gray-100'
                      }`}
                    >
                      <FileText className="w-3 h-3 text-gray-400 shrink-0" />
                      <span className="truncate">{paper.shortTitle || paper.title}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}

        {/* User uploads section if any papers without folder */}
        {papers.filter(p => !p.folderId || !folders.some(f => f.id === p.folderId)).length > 0 && (
          <div className="pt-2">
            <div className="px-2 py-1 text-[11px] font-semibold text-gray-400 uppercase tracking-wider">
              Recent Documents
            </div>
            {papers
              .filter(p => !p.folderId || !folders.some(f => f.id === p.folderId))
              .map(p => (
                <div
                  key={p.id}
                  onClick={() => onSelectPaper(p.id)}
                  className={`flex items-center gap-1.5 px-2 py-1.5 rounded cursor-pointer text-xs transition-colors ${
                    p.id === activePaperId
                      ? 'bg-indigo-100/70 text-indigo-900 font-semibold'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5 text-gray-500 shrink-0" />
                  <span className="truncate">{p.shortTitle || p.title}</span>
                </div>
              ))}
          </div>
        )}
      </div>

      {/* Support / Research Integrity Footer */}
      <div className="p-2 border-t border-[#EAECEF] bg-[#FAFAFA]">
        <button
          onClick={onOpenIntegrity}
          className="w-full flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition-colors"
        >
          <HelpCircle className="w-4 h-4 text-gray-400" />
          <span>Support & Integrity</span>
        </button>
      </div>
    </aside>
  );
};
