import React from 'react';

/**
 * Renders the multi-panel scatter plot grid corresponding to Figure 2
 * in Horvath Genome Biology 2013 matching the screenshot
 */
export const HorvathFigure2: React.FC = () => {
  const panels = [
    { label: 'A All Test', cor: '0.96', p: '<1e-200', color: '#3B82F6' },
    { label: 'B Blood CD4 T-cells', cor: '0.78', p: '4e-11', color: '#10B981' },
    { label: 'C Blood CD4+CD14', cor: '0.9', p: '6.2e-18', color: '#F59E0B' },
    { label: 'D Blood PBMC', cor: '0.96', p: '1e-200', color: '#8B5CF6' },
    { label: 'E Blood WB', cor: '0.95', p: '<1e-200', color: '#EC4899' },
    { label: 'F Brain Cerebellar', cor: '0.92', p: '1e-35', color: '#6366F1' },
    { label: 'G Brain Occipital', cor: '0.98', p: '3.2e-11', color: '#14B8A6' },
    { label: 'H Breast NL Adj', cor: '0.87', p: '1.2e-34', color: '#F43F5E' },
    { label: 'I Buccal', cor: '0.83', p: '1.1e-14', color: '#EAB308' },
    { label: 'J Colon', cor: '0.85', p: '5e-11', color: '#84CC16' },
    { label: 'K Fat Adip', cor: '0.65', p: '0.042', color: '#06B6D4' },
    { label: 'L Heart', cor: '0.77', p: '0.073', color: '#D946EF' },
    { label: 'M Kidney', cor: '0.86', p: '3.6e-09', color: '#22C55E' },
    { label: 'N Liver', cor: '0.89', p: '1.7e-13', color: '#3B82F6' },
    { label: 'O Lung NL Adj', cor: '0.87', p: '5e-09', color: '#A855F7' },
    { label: 'P Muscle', cor: '0.70', p: '1e-11', color: '#64748B' },
    { label: 'Q Saliva', cor: '0.83', p: '2.8e-14', color: '#F97316' },
    { label: 'R Uterine Cervix', cor: '0.75', p: '1e-28', color: '#EF4444' },
    { label: 'S Uterine Endomet', cor: '0.55', p: '0.0024', color: '#0EA5E9' },
    { label: 'T B-cells progeria', cor: '0.46', p: '0.073', color: '#8B5CF6' },
  ];

  return (
    <div className="my-3 border border-gray-200 rounded bg-[#FAFBFD] p-2.5 shadow-xs">
      <div className="grid grid-cols-5 gap-1.5 sm:gap-2">
        {panels.map((p, idx) => (
          <div key={idx} className="border border-gray-200 rounded bg-white p-1 flex flex-col text-[8px] leading-tight font-sans">
            <div className="font-semibold text-gray-700 truncate" title={`${p.label} r=${p.cor}`}>
              {p.label}
            </div>
            <div className="text-[7px] text-gray-400">r={p.cor}</div>
            {/* Simulated mini scatter chart */}
            <div className="relative w-full h-8 sm:h-9 bg-gray-50 border border-gray-100 rounded mt-0.5 overflow-hidden">
              {/* Regression line */}
              <div
                className="absolute w-[120%] h-[1px] bg-red-400 -left-1 top-6"
                style={{
                  transform: 'rotate(-28deg)',
                  transformOrigin: 'left center',
                }}
              />
              {/* Scatter points */}
              <div className="absolute inset-0 p-0.5 flex flex-wrap gap-0.5 items-center justify-around opacity-75">
                {[...Array(9)].map((_, i) => (
                  <span
                    key={i}
                    className="inline-block w-1 h-1 rounded-full"
                    style={{
                      backgroundColor: p.color,
                      transform: `translate(${(i % 3) * 3 - 2}px, ${(i % 2) * 2}px)`,
                    }}
                  />
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-2 text-[9px] text-gray-600 leading-normal font-sans italic">
        <span className="font-bold not-italic text-gray-800">Figure 2 Chronological age (y-axis) versus DNAm age (x-axis) in the test data.</span>{' '}
        (A) Across all test data, the age correlation is 0.96 and the error is 3.6 years. Panels B–T depict tissue-specific calibrations across blood, brain cerebellar cortex, breast, buccal epithelium, colon, myocardium, liver, and progeroid syndrome samples.
      </div>
    </div>
  );
};
