import React from 'react';
import {
  ShieldCheck,
  X,
  FileCheck2,
  AlertTriangle,
  Lightbulb,
  CheckCircle2,
  Lock,
} from 'lucide-react';

interface IntegrityModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const IntegrityModal: React.FC<IntegrityModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-xl shadow-2xl border border-gray-200 w-full max-w-xl flex flex-col font-sans overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-gray-900">Research Integrity & Evidence Protocols</h2>
              <p className="text-xs text-gray-500">Standards governing PaperPilot AI</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-md hover:bg-gray-100 text-gray-400 hover:text-gray-700 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4 text-xs text-gray-700 max-h-[70vh] overflow-y-auto leading-relaxed">
          <div className="border border-gray-200 rounded-lg p-3.5 bg-gray-50/60 space-y-1.5">
            <div className="font-bold text-gray-900 flex items-center gap-1.5">
              <FileCheck2 className="w-4 h-4 text-indigo-600" />
              1. Traceable Evidence Grounding
            </div>
            <p>
              Every factual assertion returned by PaperPilot includes in-text citation indices (e.g. <code>[1]</code>, <code>[2]</code>) that directly correspond to verified page numbers and text spans in the active document. Clicking any citation jumps directly to that page in the PDF reader.
            </p>
          </div>

          <div className="border border-gray-200 rounded-lg p-3.5 bg-gray-50/60 space-y-1.5">
            <div className="font-bold text-gray-900 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              2. Absolute Prohibition on Fabricated Citations
            </div>
            <p>
              PaperPilot will never invent DOIs, paper titles, non-existent authors, or fabricated quotations. If an answer cannot be grounded directly in the provided text, the system explicitly reports: <em>"not stated in the provided text."</em>
            </p>
          </div>

          <div className="border border-gray-200 rounded-lg p-3.5 bg-gray-50/60 space-y-1.5">
            <div className="font-bold text-gray-900 flex items-center gap-1.5">
              <Lightbulb className="w-4 h-4 text-amber-600" />
              3. Research Gap Hypothesis Labeling
            </div>
            <p>
              When exploring research gaps or unexplored opportunities across papers, suggestions are strictly categorized as <em>"Hypothesis requiring literature verification"</em>, never as established scientific consensus.
            </p>
          </div>

          <div className="border border-gray-200 rounded-lg p-3.5 bg-gray-50/60 space-y-1.5">
            <div className="font-bold text-gray-900 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              4. Scanned PDF & OCR Transparency
            </div>
            <p>
              When an uploaded PDF contains only rasterized image pages without embedded text, PaperPilot notifies the user immediately that OCR extraction is required rather than guessing or fabricating contents.
            </p>
          </div>

          <div className="border border-gray-200 rounded-lg p-3.5 bg-gray-50/60 space-y-1.5">
            <div className="font-bold text-gray-900 flex items-center gap-1.5">
              <Lock className="w-4 h-4 text-purple-600" />
              5. Untrusted Input & Prompt Neutralization
            </div>
            <p>
              Uploaded research papers are treated as untrusted data inputs. Instructions embedded inside document text attempting to override system behavior are completely ignored.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-gray-100 bg-gray-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-gray-900 hover:bg-gray-800 text-white rounded-lg text-xs font-semibold transition-colors"
          >
            Acknowledge & Close
          </button>
        </div>
      </div>
    </div>
  );
};
