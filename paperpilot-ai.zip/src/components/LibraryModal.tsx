import React, { useState } from 'react';
import {
  Search,
  X,
  FileText,
  Trash2,
  BookOpen,
  Filter,
  Plus,
  Scale,
  Download,
  Calendar,
  Layers,
  Sparkles,
} from 'lucide-react';
import { PaperDocument } from '../types';

interface LibraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  papers: PaperDocument[];
  onSelectPaper: (paperId: string) => void;
  onDeletePaper: (paperId: string) => void;
  onOpenUpload: () => void;
  onStartComparison: (paperIds: string[]) => void;
}

export const LibraryModal: React.FC<LibraryModalProps> = ({
  isOpen,
  onClose,
  papers,
  onSelectPaper,
  onDeletePaper,
  onOpenUpload,
  onStartComparison,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCollection, setSelectedCollection] = useState<string>('All');
  const [selectedPaperIds, setSelectedPaperIds] = useState<string[]>([]);

  if (!isOpen) return null;

  const collections = ['All', ...Array.from(new Set(papers.map(p => p.collection)))];

  const filteredPapers = papers.filter(p => {
    const matchesSearch =
      searchQuery === '' ||
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.authors.some(a => a.toLowerCase().includes(searchQuery.toLowerCase())) ||
      p.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesCollection = selectedCollection === 'All' || p.collection === selectedCollection;

    return matchesSearch && matchesCollection;
  });

  const toggleSelectPaper = (id: string) => {
    if (selectedPaperIds.includes(id)) {
      setSelectedPaperIds(selectedPaperIds.filter(pid => pid !== id));
    } else {
      setSelectedPaperIds([...selectedPaperIds, id]);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-xl shadow-2xl border border-gray-200 w-full max-w-4xl max-h-[85vh] flex flex-col font-sans overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-gray-900">Research Literature Library</h2>
              <p className="text-xs text-gray-500">
                {papers.length} documents in active repository
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onOpenUpload();
              }}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors shadow-2xs"
            >
              <Plus className="w-3.5 h-3.5" /> Upload Document
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-md hover:bg-gray-100 text-gray-400 hover:text-gray-700 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Search & Collection Filters */}
        <div className="p-4 border-b border-gray-100 bg-[#FAFBFD] flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 bg-white border border-gray-300 rounded-lg px-3 py-1.5 flex-1 min-w-[240px]">
            <Search className="w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search by title, author, keyword, or tag..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full outline-none text-gray-800 placeholder-gray-400 font-sans"
            />
            {searchQuery && (
              <button onClick={() => setSearchQuery('')} className="text-gray-400 hover:text-gray-600">
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Collection Pills */}
          <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
            {collections.map(col => (
              <button
                key={col}
                onClick={() => setSelectedCollection(col)}
                className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                  selectedCollection === col
                    ? 'bg-gray-900 text-white font-semibold'
                    : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'
                }`}
              >
                {col}
              </button>
            ))}
          </div>
        </div>

        {/* Selected Batch Actions Bar */}
        {selectedPaperIds.length > 0 && (
          <div className="px-6 py-2 bg-indigo-50 border-b border-indigo-100 flex items-center justify-between text-xs text-indigo-900">
            <span>
              <strong>{selectedPaperIds.length}</strong> papers selected for comparative literature analysis
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  onStartComparison(selectedPaperIds);
                  onClose();
                }}
                className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded font-medium flex items-center gap-1"
              >
                <Scale className="w-3.5 h-3.5" /> Compare Selected
              </button>
              <button
                onClick={() => setSelectedPaperIds([])}
                className="px-2 py-1 hover:bg-indigo-100 rounded text-indigo-700"
              >
                Clear
              </button>
            </div>
          </div>
        )}

        {/* Document Table / List */}
        <div className="flex-1 overflow-y-auto p-4">
          {filteredPapers.length === 0 ? (
            <div className="text-center py-12 text-gray-400 text-xs">
              No research papers matched your search or filter.
            </div>
          ) : (
            <div className="space-y-2">
              {filteredPapers.map(paper => {
                const isSelected = selectedPaperIds.includes(paper.id);
                return (
                  <div
                    key={paper.id}
                    className={`p-3 rounded-lg border transition-all flex items-center justify-between gap-4 ${
                      isSelected
                        ? 'border-indigo-400 bg-indigo-50/40'
                        : 'border-gray-200 hover:border-gray-300 bg-white hover:bg-gray-50/50'
                    }`}
                  >
                    <div className="flex items-start gap-3 flex-1 min-w-0">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleSelectPaper(paper.id)}
                        className="mt-1 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                      />
                      <div className="min-w-0 flex-1">
                        <div
                          onClick={() => {
                            onSelectPaper(paper.id);
                            onClose();
                          }}
                          className="font-serif font-bold text-sm text-gray-900 hover:text-indigo-600 cursor-pointer truncate"
                        >
                          {paper.title}
                        </div>
                        <div className="text-xs text-gray-500 flex flex-wrap items-center gap-x-2 gap-y-0.5 mt-0.5">
                          <span>{paper.authors.join(', ')}</span>
                          <span>•</span>
                          <span>{paper.journalOrConference}</span>
                          <span>•</span>
                          <span>{paper.year}</span>
                          <span>•</span>
                          <span className="font-mono">{paper.totalPages} pages</span>
                        </div>
                        {/* Tags */}
                        <div className="flex flex-wrap gap-1 mt-1.5">
                          <span className="px-1.5 py-0.5 rounded text-[10px] bg-gray-100 text-gray-600 font-medium">
                            {paper.collection}
                          </span>
                          {paper.tags.map(tag => (
                            <span
                              key={tag}
                              className="px-1.5 py-0.5 rounded text-[10px] bg-indigo-50 text-indigo-700"
                            >
                              #{tag}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => {
                          onSelectPaper(paper.id);
                          onClose();
                        }}
                        className="px-2.5 py-1.5 rounded-md bg-gray-100 hover:bg-indigo-600 hover:text-white text-gray-700 text-xs font-medium transition-colors flex items-center gap-1"
                      >
                        <BookOpen className="w-3.5 h-3.5" /> Open
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Remove "${paper.title}" from library?`)) {
                            onDeletePaper(paper.id);
                          }
                        }}
                        title="Delete paper"
                        className="p-1.5 rounded-md hover:bg-red-50 text-gray-400 hover:text-red-600 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
