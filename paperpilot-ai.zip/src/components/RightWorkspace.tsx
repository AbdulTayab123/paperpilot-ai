import React, { useState } from 'react';
import {
  Send,
  Plus,
  MoreVertical,
  ChevronDown,
  ChevronUp,
  FileText,
  Sparkles,
  Bot,
  Copy,
  Check,
  Download,
  Share2,
  Trash2,
  HelpCircle,
  ExternalLink,
  BookOpen,
  Scale,
  Compass,
  Highlighter,
  AlertCircle,
  Loader2,
  RefreshCw,
} from 'lucide-react';
import {
  ChatMessage,
  EvidenceCitation,
  PaperDocument,
  ResearchNote,
  ComparisonMatrixRow,
  ResearchGapItem,
} from '../types';

interface RightWorkspaceProps {
  activePaper: PaperDocument | null;
  allPapers: PaperDocument[];
  messages: ChatMessage[];
  onSendMessage: (text: string, model: string) => Promise<void>;
  isLoadingAI: boolean;
  onCitationClick: (citation: EvidenceCitation) => void;
  notes: ResearchNote[];
  onSaveNote: (note: ResearchNote) => void;
  onDeleteNote: (id: string) => void;
  comparisonMatrix: ComparisonMatrixRow[];
  onRunComparison: (selectedPaperIds: string[]) => Promise<void>;
  researchGaps: ResearchGapItem[];
  onExploreGaps: () => Promise<void>;
  isLoadingGaps: boolean;
  isLoadingComparison: boolean;
  onSelectPaper: (id: string) => void;
}

export const RightWorkspace: React.FC<RightWorkspaceProps> = ({
  activePaper,
  allPapers,
  messages,
  onSendMessage,
  isLoadingAI,
  onCitationClick,
  notes,
  onSaveNote,
  onDeleteNote,
  comparisonMatrix,
  onRunComparison,
  researchGaps,
  onExploreGaps,
  isLoadingGaps,
  isLoadingComparison,
  onSelectPaper,
}) => {
  const [activeTab, setActiveTab] = useState<
    'Ask' | 'Notes' | 'Details' | 'Related' | 'Annotations' | 'Compare' | 'Gaps'
  >('Ask');

  const [inputText, setInputText] = useState('');
  const [selectedModel, setSelectedModel] = useState('Opus 4.7');
  const [isModelDropdownOpen, setIsModelDropdownOpen] = useState(false);
  const [expandedThoughts, setExpandedThoughts] = useState<Record<string, boolean>>({
    'msg-initial': false,
  });

  const [activeThreadTitle, setActiveThreadTitle] = useState(
    'Twin heritability and epigenetic maintenance'
  );
  const [isThreadDropdownOpen, setIsThreadDropdownOpen] = useState(false);

  // Notes state
  const [editingNoteTitle, setEditingNoteTitle] = useState('Twin heritability and epigenetic maintenance');
  const [editingNoteContent, setEditingNoteContent] = useState(
    `### Epigenetic Maintenance System (EMS) Evidence
- Heritability in newborns: H² = 100% (MZ: 0.77, DZ: -0.21)
- Heritability in older adults: H² = 39% (MZ: 0.40, DZ: 0.20)
- Demonstrates near-total developmental genetic determinism followed by progressive environmental and stochastic epigenetic drift.
- Horvath clock (353 CpGs) acts as molecular read-out of maintenance effort.`
  );

  // Compare paper selection
  const [selectedForCompare, setSelectedForCompare] = useState<string[]>(
    allPapers.slice(0, 2).map(p => p.id)
  );

  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isLoadingAI) return;
    const text = inputText;
    setInputText('');
    await onSendMessage(text, selectedModel);
  };

  const toggleThought = (msgId: string) => {
    setExpandedThoughts(prev => ({ ...prev, [msgId]: !prev[msgId] }));
  };

  // Export comparison matrix as CSV
  const exportComparisonCsv = () => {
    if (comparisonMatrix.length === 0) return;
    const headers = ['Dimension', ...allPapers.filter(p => selectedForCompare.includes(p.id)).map(p => `"${p.title.replace(/"/g, '""')}"`)];
    const rows = comparisonMatrix.map(row => {
      const rowValues = [
        `"${row.dimension}"`,
        ...row.findings.map(f => `"${f.content.replace(/"/g, '""')}"`),
      ];
      return rowValues.join(',');
    });
    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `paperpilot_comparison_matrix_${Date.now()}.csv`;
    a.click();
  };

  return (
    <div className="w-[380px] lg:w-[420px] xl:w-[450px] h-full bg-[#FFFFFF] border-l border-[#E5E7EB] flex flex-col shrink-0 font-sans text-[#1F2328] select-text">
      {/* 1. Header with Mode Tabs & Agent button */}
      <div className="px-3 pt-2.5 pb-1 border-b border-[#EAECEF] bg-[#FFFFFF] shrink-0">
        <div className="flex items-center justify-between mb-2">
          {/* Tabs matching screenshot: Ask | Notes | Details | Related | Annotations */}
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar text-xs">
            {(['Ask', 'Notes', 'Details', 'Compare', 'Gaps', 'Annotations'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`py-1 px-1.5 font-medium transition-colors border-b-2 whitespace-nowrap ${
                  activeTab === tab
                    ? 'border-gray-900 text-gray-900 font-bold'
                    : 'border-transparent text-gray-500 hover:text-gray-800'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Top-Right "▷ Agent" Pill */}
          <button
            onClick={() => {
              setActiveTab('Ask');
              setInputText('Provide an autonomous multi-paper synthesis of epigenetic clocks vs senolytics.');
            }}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-gray-100 hover:bg-gray-200 text-gray-800 transition-colors shrink-0 ml-1"
          >
            <span className="text-[11px] leading-none text-indigo-600">▷</span>
            <span>Agent</span>
          </button>
        </div>

        {/* Active conversation thread title matching screenshot */}
        {activeTab === 'Ask' && (
          <div className="flex items-center justify-between py-1 border-t border-gray-100 relative">
            <button
              onClick={() => setIsThreadDropdownOpen(!isThreadDropdownOpen)}
              className="flex items-center gap-1 text-xs font-medium text-gray-700 hover:text-gray-900 truncate max-w-[280px]"
            >
              <span className="truncate">{activeThreadTitle}</span>
              <ChevronDown className="w-3.5 h-3.5 text-gray-400 shrink-0" />
            </button>

            <div className="flex items-center gap-1 text-gray-400">
              <button
                onClick={() => {
                  const title = prompt('Enter research thread question:', 'New Research Topic');
                  if (title) setActiveThreadTitle(title);
                }}
                title="New conversation"
                className="p-1 rounded hover:bg-gray-100 hover:text-gray-700"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => alert(`Active Thread: ${activeThreadTitle}\nDocuments in view: ${allPapers.length}`)}
                className="p-1 rounded hover:bg-gray-100 hover:text-gray-700"
              >
                <MoreVertical className="w-3.5 h-3.5" />
              </button>
            </div>

            {isThreadDropdownOpen && (
              <div className="absolute top-8 left-0 w-72 bg-white border border-gray-200 rounded-lg shadow-xl z-50 py-1 text-xs">
                <button
                  onClick={() => {
                    setActiveThreadTitle('Twin heritability and epigenetic maintenance');
                    setIsThreadDropdownOpen(false);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-gray-50 font-medium text-gray-800 truncate"
                >
                  Twin heritability and epigenetic maintenance
                </button>
                <button
                  onClick={() => {
                    setActiveThreadTitle('Senolytics clinical translational efficacy');
                    setIsThreadDropdownOpen(false);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-gray-50 text-gray-700 truncate"
                >
                  Senolytics clinical translational efficacy
                </button>
                <button
                  onClick={() => {
                    setActiveThreadTitle('OSKM Yamanaka reprogramming dynamics');
                    setIsThreadDropdownOpen(false);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-gray-50 text-gray-700 truncate"
                >
                  OSKM Yamanaka reprogramming dynamics
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* 2. Main Content Body Depending on Selected Tab */}
      <div className="flex-1 overflow-y-auto p-3 space-y-4 text-xs font-sans">
        {/* TAB 1: ASK (Evidence Grounded Q&A Matching Screenshot) */}
        {activeTab === 'Ask' && (
          <div className="space-y-4">
            {messages.map(msg => (
              <div key={msg.id} className="space-y-2">
                {msg.sender === 'user' ? (
                  /* User Bubble Matching Screenshot */
                  <div className="flex justify-end">
                    <div className="bg-[#F0F2F5] text-[#1F2328] px-3.5 py-2.5 rounded-2xl max-w-[90%] text-xs leading-relaxed font-sans shadow-2xs">
                      {msg.text}
                    </div>
                  </div>
                ) : (
                  /* Assistant Response Matching Screenshot */
                  <div className="space-y-2.5">
                    {/* Collapsible Reasoning Banner */}
                    {msg.thoughtSteps && (
                      <div className="border border-gray-100 rounded-md bg-[#FAFBFD] p-2 text-xs">
                        <button
                          onClick={() => toggleThought(msg.id)}
                          className="w-full flex items-center justify-between text-gray-500 hover:text-gray-800 font-medium"
                        >
                          <span className="flex items-center gap-1.5">
                            <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                            {msg.thoughtSteps}
                          </span>
                          {expandedThoughts[msg.id] ? (
                            <ChevronUp className="w-3.5 h-3.5 text-gray-400" />
                          ) : (
                            <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
                          )}
                        </button>

                        {expandedThoughts[msg.id] && (
                          <div className="mt-2 pt-2 border-t border-gray-100 text-[11px] text-gray-600 space-y-1.5 font-mono">
                            <div>• Passage retrieval: Scanned 19 pages of Horvath (2013).</div>
                            <div>• Grounding: Falconer's heritability formula matched on Page 5.</div>
                            <div>• Cross-check: Genetic correlation (0.77 MZ vs -0.21 DZ) supports EMS model.</div>
                          </div>
                        )}
                      </div>
                    )}

                    {/* AI Answer Text with In-Text Interactive Citations */}
                    <div className="text-gray-900 leading-relaxed font-serif text-[13px] space-y-2.5">
                      {msg.isError ? (
                        <div className="bg-red-50 border border-red-200 text-red-800 p-3 rounded-lg flex items-start gap-2">
                          <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                          <div>
                            <strong className="block font-sans text-xs">AI Inference Error</strong>
                            <span className="font-sans text-xs">{msg.text}</span>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-3">
                          {msg.text.split('\n\n').map((para, idx) => (
                            <p key={idx} className="leading-relaxed">
                              {para}
                            </p>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Interactive Citation Pill Badges */}
                    {msg.citations && msg.citations.length > 0 && (
                      <div className="flex flex-wrap items-center gap-1.5 pt-1">
                        <span className="text-[10px] text-gray-400 font-sans">Evidence citations:</span>
                        {msg.citations.map(citation => (
                          <button
                            key={citation.id}
                            onClick={() => onCitationClick(citation)}
                            title={`Jump to Page ${citation.pageNumber} in "${citation.docTitle}":\n"${citation.passageText.substring(0, 100)}..."`}
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-700 font-mono text-[11px] font-semibold transition-colors shadow-2xs group"
                          >
                            <span className="w-3.5 h-3.5 rounded-full bg-indigo-600 text-white flex items-center justify-center text-[9px] group-hover:scale-105 transition-transform">
                              {citation.id}
                            </span>
                            <span>p.{citation.pageNumber}</span>
                          </button>
                        ))}
                      </div>
                    )}

                    {/* Source Document Card Matching Screenshot */}
                    {msg.sourceDocs && msg.sourceDocs.length > 0 && (
                      <div className="pt-1">
                        {msg.sourceDocs.map(doc => (
                          <div
                            key={doc.id}
                            onClick={() => onSelectPaper(doc.id)}
                            className="flex items-center gap-2 p-2 rounded-lg bg-[#F8F9FA] border border-gray-200 hover:border-indigo-300 hover:bg-indigo-50/40 cursor-pointer transition-colors"
                          >
                            <FileText className="w-4 h-4 text-indigo-600 shrink-0" />
                            <span className="truncate text-xs font-medium text-gray-800">
                              {doc.title}
                            </span>
                            <span className="ml-auto text-[10px] text-gray-400 shrink-0 font-sans">
                              Active source
                            </span>
                          </div>
                        ))}
                      </div>
                    )}

                    <div className="flex items-center justify-end gap-2 pt-1 text-[11px] text-gray-400">
                      <button
                        onClick={() => handleCopy(msg.text, msg.id)}
                        className="hover:text-gray-700 flex items-center gap-1"
                      >
                        {copiedId === msg.id ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-600" /> Copied
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" /> Copy Answer
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}

            {isLoadingAI && (
              <div className="flex items-center gap-2 p-3 bg-indigo-50/50 rounded-lg border border-indigo-100 text-indigo-800 text-xs font-sans">
                <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />
                <span>Searching document chunks and verifying evidence passages...</span>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: NOTES & EXPORTS */}
        {activeTab === 'Notes' && (
          <div className="space-y-3 font-sans">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-gray-900 text-xs">Research Workspace Notes</span>
              <div className="flex gap-1.5">
                <button
                  onClick={() => {
                    const blob = new Blob([`# ${editingNoteTitle}\n\n${editingNoteContent}`], {
                      type: 'text/markdown;charset=utf-8;',
                    });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `notes_${editingNoteTitle.replace(/\s+/g, '_')}.md`;
                    a.click();
                  }}
                  className="px-2 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded text-[11px] font-medium flex items-center gap-1"
                >
                  <Download className="w-3 h-3" /> Export .MD
                </button>
              </div>
            </div>

            <input
              type="text"
              value={editingNoteTitle}
              onChange={e => setEditingNoteTitle(e.target.value)}
              placeholder="Note title..."
              className="w-full font-bold text-sm text-gray-900 border-b border-gray-200 pb-1 outline-none focus:border-indigo-600"
            />

            <textarea
              rows={12}
              value={editingNoteContent}
              onChange={e => setEditingNoteContent(e.target.value)}
              placeholder="Write Markdown research notes, paste passages, synthesize findings..."
              className="w-full text-xs font-mono p-2.5 border border-gray-200 rounded-lg outline-none focus:border-indigo-600 focus:ring-1 focus:ring-indigo-100 leading-relaxed resize-y"
            />

            <div className="p-2.5 bg-gray-50 border border-gray-200 rounded-lg text-[11px] text-gray-600 space-y-1">
              <div className="font-semibold text-gray-800">Saved Research Notes:</div>
              {notes.map(n => (
                <div
                  key={n.id}
                  onClick={() => {
                    setEditingNoteTitle(n.title);
                    setEditingNoteContent(n.content);
                  }}
                  className="p-1.5 rounded hover:bg-white cursor-pointer border border-transparent hover:border-gray-200 flex justify-between items-center"
                >
                  <span className="truncate">{n.title}</span>
                  <span className="text-[10px] text-gray-400">
                    {new Date(n.updatedAt).toLocaleDateString()}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: DETAILS & METADATA */}
        {activeTab === 'Details' && (
          <div className="space-y-3 font-sans">
            {activePaper ? (
              <>
                <div className="border border-gray-200 rounded-lg p-3 bg-[#FAFBFD] space-y-2">
                  <h3 className="font-serif font-bold text-sm text-gray-950 leading-snug">
                    {activePaper.title}
                  </h3>
                  <div className="text-xs text-gray-600">
                    <strong>Authors:</strong> {activePaper.authors.join(', ')}
                  </div>
                  <div className="text-xs text-gray-600">
                    <strong>Publication:</strong> {activePaper.journalOrConference} ({activePaper.year})
                  </div>
                  {activePaper.doi && (
                    <div className="text-xs text-indigo-600 flex items-center gap-1">
                      <strong>DOI:</strong> {activePaper.doi}
                    </div>
                  )}
                  {activePaper.citationsCount && (
                    <div className="text-xs text-gray-600">
                      <strong>Citations:</strong> {activePaper.citationsCount.toLocaleString()}
                    </div>
                  )}
                  <div className="text-xs text-gray-600">
                    <strong>Pages:</strong> {activePaper.totalPages} pages ({activePaper.fileSize})
                  </div>
                </div>

                <div className="border border-gray-200 rounded-lg p-3 bg-white space-y-1.5">
                  <span className="font-bold text-xs text-gray-800 block">Abstract</span>
                  <p className="font-serif text-xs leading-relaxed text-gray-700 text-justify">
                    {activePaper.abstract}
                  </p>
                </div>

                {activePaper.bibtex && (
                  <div className="border border-gray-200 rounded-lg p-3 bg-gray-50 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-gray-800">BibTeX Citation</span>
                      <button
                        onClick={() => handleCopy(activePaper.bibtex || '', 'bibtex')}
                        className="text-[11px] text-indigo-600 hover:text-indigo-800 font-medium flex items-center gap-1"
                      >
                        {copiedId === 'bibtex' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                        {copiedId === 'bibtex' ? 'Copied' : 'Copy BibTeX'}
                      </button>
                    </div>
                    <pre className="text-[10px] font-mono p-2 bg-white border border-gray-200 rounded overflow-x-auto text-gray-700">
                      {activePaper.bibtex}
                    </pre>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center py-6 text-gray-500">No active paper selected</div>
            )}
          </div>
        )}

        {/* TAB 4: COMPARE (Multi-Paper Cross-Analysis) */}
        {activeTab === 'Compare' && (
          <div className="space-y-3 font-sans">
            <div className="border border-gray-200 rounded-lg p-3 bg-gray-50 space-y-2">
              <span className="font-bold text-xs text-gray-900 block">Select Papers to Compare</span>
              <div className="space-y-1 max-h-36 overflow-y-auto">
                {allPapers.map(paper => (
                  <label key={paper.id} className="flex items-center gap-2 cursor-pointer text-xs">
                    <input
                      type="checkbox"
                      checked={selectedForCompare.includes(paper.id)}
                      onChange={e => {
                        if (e.target.checked) {
                          setSelectedForCompare([...selectedForCompare, paper.id]);
                        } else {
                          setSelectedForCompare(selectedForCompare.filter(id => id !== paper.id));
                        }
                      }}
                      className="rounded text-indigo-600 focus:ring-indigo-500"
                    />
                    <span className="truncate">{paper.shortTitle || paper.title}</span>
                  </label>
                ))}
              </div>
              <div className="flex items-center justify-between pt-1">
                <button
                  onClick={() => onRunComparison(selectedForCompare)}
                  disabled={selectedForCompare.length < 2 || isLoadingComparison}
                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white rounded font-medium text-xs flex items-center gap-1.5 transition-colors"
                >
                  {isLoadingComparison ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" /> Comparing...
                    </>
                  ) : (
                    <>
                      <Scale className="w-3.5 h-3.5" /> Generate Comparison Matrix
                    </>
                  )}
                </button>

                {comparisonMatrix.length > 0 && (
                  <button
                    onClick={exportComparisonCsv}
                    className="px-2.5 py-1.5 border border-gray-300 hover:bg-white rounded text-xs font-medium text-gray-700 flex items-center gap-1"
                  >
                    <Download className="w-3 h-3" /> CSV Export
                  </button>
                )}
              </div>
            </div>

            {/* Comparison Matrix Table */}
            {comparisonMatrix.length > 0 ? (
              <div className="space-y-3">
                {comparisonMatrix.map((row, idx) => (
                  <div key={idx} className="border border-gray-200 rounded-lg p-2.5 bg-white space-y-1.5 shadow-2xs">
                    <div className="font-bold text-xs text-indigo-950 border-b border-gray-100 pb-1">
                      {row.dimension}
                    </div>
                    <div className="space-y-1.5">
                      {row.findings.map((finding, fIdx) => (
                        <div key={fIdx} className="text-[11px] leading-relaxed">
                          <span className="font-semibold text-gray-800">{finding.docTitle}: </span>
                          <span className={finding.isNotStated ? 'text-gray-400 italic' : 'text-gray-700'}>
                            {finding.content}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 text-gray-500 text-xs">
                Select 2 or more papers above and click "Generate Comparison Matrix" to analyze objectives, methods, datasets, results, limitations, and future work.
              </div>
            )}
          </div>
        )}

        {/* TAB 5: RESEARCH GAPS & HYPOTHESES */}
        {activeTab === 'Gaps' && (
          <div className="space-y-3 font-sans">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-gray-900">Literature Gaps & Hypotheses</span>
              <button
                onClick={onExploreGaps}
                disabled={isLoadingGaps}
                className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded text-xs font-medium flex items-center gap-1 transition-colors"
              >
                {isLoadingGaps ? <Loader2 className="w-3 h-3 animate-spin" /> : <Compass className="w-3 h-3" />}
                Explore Gaps
              </button>
            </div>

            <div className="p-2 bg-amber-50 border border-amber-200 rounded text-[11px] text-amber-900 flex items-start gap-1.5">
              <AlertCircle className="w-3.5 h-3.5 text-amber-700 shrink-0 mt-0.5" />
              <span>
                <strong>Research Integrity Notice:</strong> All identified gaps are structured hypotheses requiring literature verification, not empirical consensus.
              </span>
            </div>

            {researchGaps.map((gap, gIdx) => (
              <div key={gIdx} className="border border-gray-200 rounded-lg p-3 bg-white space-y-2 shadow-2xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-gray-900">{gap.gapTitle}</span>
                  <span className="px-1.5 py-0.5 bg-gray-100 border border-gray-200 text-gray-600 rounded text-[10px]">
                    {gap.category}
                  </span>
                </div>
                <div className="text-[11px] text-gray-600">
                  <strong>Current Observation:</strong> {gap.observation}
                </div>
                <div className="p-2 bg-indigo-50/70 border border-indigo-200 rounded text-[11px] text-indigo-950 font-medium">
                  {gap.hypothesis}
                </div>
                <div className="text-[11px] text-gray-500">
                  <strong>Suggested Study:</strong> {gap.suggestedStudy}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* TAB 6: ANNOTATIONS & TRACEABILITY */}
        {activeTab === 'Annotations' && (
          <div className="space-y-2 font-sans">
            <span className="font-bold text-xs text-gray-900 block">Document Citations & Traceability</span>
            {messages.flatMap(m => m.citations || []).length === 0 ? (
              <div className="text-center py-6 text-gray-500 text-xs">
                No citations generated yet. Ask questions in the "Ask" tab to extract traceable citations.
              </div>
            ) : (
              messages
                .flatMap(m => m.citations || [])
                .map((cit, idx) => (
                  <div
                    key={idx}
                    onClick={() => onCitationClick(cit)}
                    className="p-2.5 rounded-lg border border-gray-200 hover:border-indigo-300 bg-white hover:bg-indigo-50/30 cursor-pointer transition-colors space-y-1"
                  >
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-semibold text-indigo-900 flex items-center gap-1">
                        <span className="w-3.5 h-3.5 rounded-full bg-indigo-600 text-white flex items-center justify-center text-[9px]">
                          {cit.id}
                        </span>
                        {cit.docTitle}
                      </span>
                      <span className="text-gray-400 font-mono">Page {cit.pageNumber}</span>
                    </div>
                    <p className="text-[11px] text-gray-600 line-clamp-3 font-serif">
                      "{cit.passageText}"
                    </p>
                  </div>
                ))
            )}
          </div>
        )}
      </div>

      {/* 3. Bottom Input Bar Matching Screenshot */}
      {activeTab === 'Ask' && (
        <div className="p-3 border-t border-[#EAECEF] bg-[#FFFFFF] shrink-0">
          <form onSubmit={handleSend} className="space-y-2">
            <div className="relative border border-[#D0D7DE] focus-within:border-indigo-600 focus-within:ring-1 focus-within:ring-indigo-100 rounded-xl bg-white shadow-2xs overflow-hidden">
              <textarea
                rows={2}
                value={inputText}
                onChange={e => setInputText(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSend(e);
                  }
                }}
                placeholder="Ask about files in view..."
                className="w-full px-3 py-2 text-xs outline-none text-[#1F2328] placeholder-gray-400 resize-none font-sans"
              />

              {/* Bottom Actions inside input card matching screenshot */}
              <div className="flex items-center justify-between px-2.5 pb-2 pt-0.5 text-xs text-gray-500">
                {/* Model Selector Dropdown: "Opus 4.7 v" */}
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setIsModelDropdownOpen(!isModelDropdownOpen)}
                    className="flex items-center gap-1 text-[11px] font-medium text-gray-700 hover:text-gray-900 px-1.5 py-0.5 rounded hover:bg-gray-100 transition-colors"
                  >
                    <span>{selectedModel}</span>
                    <ChevronDown className="w-3 h-3 text-gray-400" />
                  </button>

                  {isModelDropdownOpen && (
                    <div className="absolute bottom-7 left-0 bg-white border border-gray-200 rounded-lg shadow-xl py-1 w-44 z-50 text-xs">
                      {['Gemini 3.8 Flash', 'Gemini 3.1 Pro', 'Opus 4.7'].map(m => (
                        <button
                          key={m}
                          type="button"
                          onClick={() => {
                            setSelectedModel(m);
                            setIsModelDropdownOpen(false);
                          }}
                          className={`w-full text-left px-3 py-1.5 hover:bg-gray-50 flex items-center justify-between ${
                            selectedModel === m ? 'font-bold text-indigo-600' : 'text-gray-700'
                          }`}
                        >
                          <span>{m}</span>
                          {selectedModel === m && <Check className="w-3.5 h-3.5 text-indigo-600" />}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Right controls: [+] attachment and [↑] send button */}
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      setInputText(prev => prev + ' Compare against Horvath 2013 and Kirkland 2020.');
                    }}
                    title="Add paper reference context"
                    className="p-1 rounded hover:bg-gray-100 text-gray-500 hover:text-gray-800 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                  </button>

                  <button
                    type="submit"
                    disabled={!inputText.trim() || isLoadingAI}
                    className="p-1.5 rounded-full bg-gray-900 hover:bg-indigo-600 disabled:opacity-30 disabled:hover:bg-gray-900 text-white transition-colors"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
