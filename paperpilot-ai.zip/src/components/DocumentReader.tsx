import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  ZoomIn,
  ZoomOut,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  X,
  Plus,
  Maximize2,
  Minimize2,
  FileText,
  MoreHorizontal,
  Bookmark,
  Share2,
  AlertTriangle,
  Highlighter,
  Quote,
  Copy,
  Check,
  PanelRightClose,
  PanelRightOpen,
  Sidebar as SidebarIcon,
} from 'lucide-react';
import { PaperDocument } from '../types';
import { HorvathFigure2 } from './HorvathFigure';

interface DocumentReaderProps {
  openPapers: PaperDocument[];
  activePaperId: string | null;
  onSelectPaper: (paperId: string) => void;
  onClosePaperTab: (paperId: string) => void;
  onOpenUpload: () => void;
  highlightedCitation: { docId: string; pageNumber: number; text?: string } | null;
  onAddNoteFromQuote?: (quote: string, pageNumber: number, paperTitle: string) => void;
  isRightPanelOpen: boolean;
  onToggleRightPanel: () => void;
}

export const DocumentReader: React.FC<DocumentReaderProps> = ({
  openPapers,
  activePaperId,
  onSelectPaper,
  onClosePaperTab,
  onOpenUpload,
  highlightedCitation,
  onAddNoteFromQuote,
  isRightPanelOpen,
  onToggleRightPanel,
}) => {
  const activePaper = openPapers.find(p => p.id === activePaperId) || openPapers[0];

  const [currentPage, setCurrentPage] = useState<number>(5);
  const [zoomLevel, setZoomLevel] = useState<number>(81); // 81% from screenshot
  const [isZoomMenuOpen, setIsZoomMenuOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);
  const [copiedNotification, setCopiedNotification] = useState(false);
  const [selectedText, setSelectedText] = useState('');
  const [selectionPosition, setSelectionPosition] = useState<{ x: number; y: number } | null>(null);

  const pageContainerRef = useRef<HTMLDivElement>(null);

  // Sync current page if citation is clicked
  useEffect(() => {
    if (highlightedCitation && highlightedCitation.docId === activePaper?.id) {
      setCurrentPage(highlightedCitation.pageNumber);
      // scroll page into view smoothly
      setTimeout(() => {
        const el = document.getElementById(`doc-page-${highlightedCitation.pageNumber}`);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 100);
    }
  }, [highlightedCitation, activePaper]);

  // Handle text selection on reading canvas
  const handleMouseUp = () => {
    const selection = window.getSelection();
    if (selection && selection.toString().trim().length > 3) {
      const text = selection.toString().trim();
      setSelectedText(text);
      const range = selection.getRangeAt(0);
      const rect = range.getBoundingClientRect();
      setSelectionPosition({
        x: rect.left + rect.width / 2,
        y: rect.top - 40,
      });
    } else {
      setSelectedText('');
      setSelectionPosition(null);
    }
  };

  const handleCopyText = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 2000);
  };

  if (!activePaper) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-[#F8F9FA] text-gray-500 p-8">
        <div className="max-w-md text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center mx-auto text-indigo-600">
            <FileText className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-serif font-bold text-gray-900">No Document Opened</h2>
          <p className="text-sm text-gray-500 leading-relaxed">
            Select a paper from the library or upload a research PDF/TXT to start reading with page-level evidence citation.
          </p>
          <button
            onClick={onOpenUpload}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-lg shadow-sm transition-colors inline-flex items-center gap-2"
          >
            <Plus className="w-4 h-4" /> Upload Research Paper
          </button>
        </div>
      </div>
    );
  }

  const activePageObj = activePaper.pages.find(p => p.pageNumber === currentPage) || activePaper.pages[0];

  return (
    <div className="flex-1 flex flex-col h-full bg-[#EAECEF] overflow-hidden select-text relative">
      {/* 1. Tab Bar Matching Screenshot */}
      <div className="flex items-center bg-[#F1F3F5] border-b border-[#D8DEE4] px-2 pt-1.5 gap-1 shrink-0 overflow-x-auto no-scrollbar">
        {openPapers.map(paper => {
          const isActive = paper.id === activePaper.id;
          return (
            <div
              key={paper.id}
              onClick={() => onSelectPaper(paper.id)}
              className={`group flex items-center gap-2 px-3 py-1.5 rounded-t-md text-xs font-medium cursor-pointer transition-all border-t border-x ${
                isActive
                  ? 'bg-white border-[#D8DEE4] border-b-transparent text-gray-900 shadow-2xs font-semibold'
                  : 'bg-transparent border-transparent text-gray-600 hover:bg-gray-200/60'
              }`}
            >
              <FileText className={`w-3.5 h-3.5 ${isActive ? 'text-indigo-600' : 'text-gray-400'}`} />
              <span className="truncate max-w-[130px]">{paper.shortTitle || paper.title}</span>
              <button
                onClick={e => {
                  e.stopPropagation();
                  onClosePaperTab(paper.id);
                }}
                className="p-0.5 rounded-sm hover:bg-gray-200 text-gray-400 hover:text-gray-700 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          );
        })}

        <button
          onClick={onOpenUpload}
          title="Open or Upload Document"
          className="p-1.5 rounded-md hover:bg-gray-200/80 text-gray-500 hover:text-gray-800 transition-colors ml-1"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      {/* 2. Document Reader Toolbar Matching Screenshot */}
      <div className="h-10 bg-white border-b border-[#D8DEE4] flex items-center justify-between px-3 shrink-0 text-xs text-gray-700 font-sans shadow-2xs">
        {/* Left Toolbar Items: [Thumbnail] [Search] [Fit/Select] [Zoom % v] */}
        <div className="flex items-center gap-1 sm:gap-2">
          <button
            onClick={() => setIsSearchOpen(!isSearchOpen)}
            title="Search in document"
            className="p-1.5 rounded hover:bg-gray-100 text-gray-600 hover:text-gray-900 transition-colors"
          >
            <Search className="w-4 h-4" />
          </button>

          <button
            onClick={() => setZoomLevel(100)}
            title="Actual size 100%"
            className="p-1.5 rounded hover:bg-gray-100 text-gray-600 hover:text-gray-900 transition-colors"
          >
            <Maximize2 className="w-4 h-4" />
          </button>

          {/* Zoom Level Dropdown */}
          <div className="relative">
            <button
              onClick={() => setIsZoomMenuOpen(!isZoomMenuOpen)}
              className="flex items-center gap-1 px-2 py-1 rounded hover:bg-gray-100 text-gray-700 font-medium transition-colors"
            >
              <span>{zoomLevel}%</span>
              <ChevronDown className="w-3 h-3 text-gray-400" />
            </button>

            {isZoomMenuOpen && (
              <div className="absolute top-8 left-0 bg-white border border-gray-200 rounded-lg shadow-lg py-1 w-24 z-50">
                {[50, 75, 81, 100, 125, 150].map(z => (
                  <button
                    key={z}
                    onClick={() => {
                      setZoomLevel(z);
                      setIsZoomMenuOpen(false);
                    }}
                    className={`w-full text-left px-3 py-1 hover:bg-gray-50 text-xs flex justify-between ${
                      zoomLevel === z ? 'font-bold text-indigo-600' : 'text-gray-700'
                    }`}
                  >
                    <span>{z}%</span>
                    {zoomLevel === z && <Check className="w-3 h-3 text-indigo-600" />}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Center Page Controls: < 5 of 20 > */}
        <div className="flex items-center gap-1 sm:gap-2 bg-gray-50 px-2 py-0.5 rounded border border-gray-200">
          <button
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={currentPage <= 1}
            className="p-1 rounded hover:bg-gray-200/80 disabled:opacity-30 disabled:hover:bg-transparent text-gray-600 transition-colors"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>

          <div className="flex items-center gap-1 font-mono text-xs">
            <input
              type="text"
              value={currentPage}
              onChange={e => {
                const val = parseInt(e.target.value, 10);
                if (!isNaN(val) && val >= 1 && val <= activePaper.totalPages) {
                  setCurrentPage(val);
                }
              }}
              className="w-7 text-center font-semibold bg-white border border-gray-300 rounded py-0.5 outline-none focus:border-indigo-500"
            />
            <span className="text-gray-500">of {activePaper.totalPages}</span>
          </div>

          <button
            onClick={() => setCurrentPage(p => Math.min(activePaper.totalPages, p + 1))}
            disabled={currentPage >= activePaper.totalPages}
            className="p-1 rounded hover:bg-gray-200/80 disabled:opacity-30 disabled:hover:bg-transparent text-gray-600 transition-colors"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Right Action Icons: [...] [Toggle AI Panel] */}
        <div className="flex items-center gap-1">
          <div className="relative">
            <button
              onClick={() => setIsMoreMenuOpen(!isMoreMenuOpen)}
              title="More document actions"
              className="p-1.5 rounded hover:bg-gray-100 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <MoreHorizontal className="w-4 h-4" />
            </button>

            {isMoreMenuOpen && (
              <div className="absolute top-8 right-0 bg-white border border-gray-200 rounded-lg shadow-lg py-1 w-44 z-50 text-xs">
                <button
                  onClick={() => {
                    handleCopyText(activePaper.abstract);
                    setIsMoreMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-gray-50 text-gray-700 flex items-center gap-2"
                >
                  <Copy className="w-3.5 h-3.5" /> Copy Abstract
                </button>
                <button
                  onClick={() => {
                    handleCopyText(activePaper.bibtex || '');
                    setIsMoreMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-gray-50 text-gray-700 flex items-center gap-2"
                >
                  <Quote className="w-3.5 h-3.5" /> Copy BibTeX Citation
                </button>
                <button
                  onClick={() => {
                    alert(`Paper: ${activePaper.title}\nTotal Pages: ${activePaper.totalPages}\nAuthors: ${activePaper.authors.join(', ')}`);
                    setIsMoreMenuOpen(false);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-gray-50 text-gray-700 flex items-center gap-2"
                >
                  <Bookmark className="w-3.5 h-3.5" /> Document Metadata
                </button>
              </div>
            )}
          </div>

          <button
            onClick={onToggleRightPanel}
            title={isRightPanelOpen ? 'Collapse AI panel' : 'Expand AI panel'}
            className="p-1.5 rounded hover:bg-gray-100 text-gray-600 hover:text-gray-900 transition-colors"
          >
            {isRightPanelOpen ? (
              <PanelRightClose className="w-4 h-4" />
            ) : (
              <PanelRightOpen className="w-4 h-4" />
            )}
          </button>
        </div>
      </div>

      {/* In-Document Search Bar */}
      {isSearchOpen && (
        <div className="bg-white border-b border-gray-200 px-4 py-2 flex items-center gap-3 text-xs shadow-xs z-30">
          <Search className="w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search text in paper..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="flex-1 outline-none text-gray-800 placeholder-gray-400 font-sans"
            autoFocus
          />
          {searchTerm && (
            <span className="text-gray-400 font-mono text-[11px]">
              {activePaper.pages.filter(p => p.text.toLowerCase().includes(searchTerm.toLowerCase())).length} pages matched
            </span>
          )}
          <button
            onClick={() => {
              setSearchTerm('');
              setIsSearchOpen(false);
            }}
            className="p-1 hover:bg-gray-100 rounded text-gray-400 hover:text-gray-700"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Scanned PDF OCR Banner if applicable */}
      {activePaper.needsOcr && (
        <div className="bg-amber-50 border-b border-amber-200 px-4 py-2 flex items-center justify-between text-xs text-amber-800 z-20">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              <strong>Scanned PDF Detected:</strong> This document contains raster image pages without embedded text layers. Visual pages are displayed; run OCR or upload text-embedded PDF for full semantic retrieval.
            </span>
          </div>
          <button
            onClick={() => alert('Simulating high-accuracy OCR extraction on document... Text layer generated.')}
            className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded font-medium shrink-0 ml-3"
          >
            Run OCR Engine
          </button>
        </div>
      )}

      {/* Copied notification toast */}
      {copiedNotification && (
        <div className="absolute top-14 left-1/2 -translate-x-1/2 bg-gray-900 text-white text-xs px-3 py-1.5 rounded-full shadow-lg z-50 flex items-center gap-1.5">
          <Check className="w-3.5 h-3.5 text-emerald-400" />
          <span>Copied to clipboard</span>
        </div>
      )}

      {/* Selection floating toolbar */}
      {selectionPosition && selectedText && (
        <div
          className="fixed bg-gray-900 text-white text-xs rounded-lg shadow-xl px-2 py-1.5 flex items-center gap-2 z-50 pointer-events-auto"
          style={{
            left: `${selectionPosition.x}px`,
            top: `${selectionPosition.y}px`,
            transform: 'translateX(-50%)',
          }}
        >
          <button
            onClick={() => {
              if (onAddNoteFromQuote) {
                onAddNoteFromQuote(selectedText, currentPage, activePaper.title);
              }
              setSelectionPosition(null);
            }}
            className="flex items-center gap-1 hover:text-indigo-300 font-medium px-1.5 py-0.5 rounded hover:bg-gray-800"
          >
            <Highlighter className="w-3 h-3 text-amber-400" /> Save Note
          </button>
          <span className="text-gray-600">|</span>
          <button
            onClick={() => {
              handleCopyText(selectedText);
              setSelectionPosition(null);
            }}
            className="flex items-center gap-1 hover:text-indigo-300 font-medium px-1.5 py-0.5 rounded hover:bg-gray-800"
          >
            <Copy className="w-3 h-3" /> Copy
          </button>
        </div>
      )}

      {/* 3. Main Document View Canvas */}
      <div
        ref={pageContainerRef}
        onMouseUp={handleMouseUp}
        className="flex-1 overflow-y-auto p-4 sm:p-6 flex justify-center items-start scroll-smooth"
      >
        <div
          id={`doc-page-${currentPage}`}
          className="bg-white shadow-md border border-[#D0D7DE] rounded-xs transition-transform origin-top flex flex-col"
          style={{
            width: `${Math.round(820 * (zoomLevel / 100))}px`,
            minHeight: `${Math.round(1080 * (zoomLevel / 100))}px`,
            padding: `${Math.round(44 * (zoomLevel / 100))}px ${Math.round(48 * (zoomLevel / 100))}px`,
          }}
        >
          {/* Authentic Document Page Header */}
          <div className="border-b border-gray-200 pb-2 mb-4 flex justify-between items-center text-[11px] text-gray-500 font-serif">
            <span>{activePageObj.headerText || `${activePaper.title}`}</span>
            <span className="font-sans font-medium text-gray-600">
              Page {activePageObj.pageNumber} of {activePaper.totalPages}
            </span>
          </div>

          {/* Special Horvath Paper Page 4 & 5 Exact Authentic Layout */}
          {activePaper.id === 'paper-horvath-2013' && currentPage === 4 && (
            <div className="flex-1 flex flex-col font-serif text-[13px] leading-relaxed text-[#24292F]">
              {/* Figure 2 Scatter Plots Grid */}
              <HorvathFigure2 />

              {/* Two Column Academic Layout */}
              <div className="grid grid-cols-2 gap-5 mt-2">
                <div className="space-y-2.5">
                  <p className="text-justify">
                    (Age, DNAmAge)' and 'Median Error(Age, DNAmAge)' in Additional file 1). An obvious limitation of this approach is that it leads to biased results in the training data sets. As suggested by its name, this approach estimates the DNAm age for each data set (considered as test data set) separately by fitting a separate multi-tissue age predictor to the remaining (left out) data sets. The resulting unbiased estimates of predictive accuracy can be found in Additional file 1: columns 'Cor LOOCV' and 'Error LOOCV', respectively.
                  </p>
                  <p className="text-justify">
                    Data sets differ greatly with respect to the median chronological age and the standard deviation, which is defined as the square root of the variance of age. Some data sets involve samples with the same age (standard deviation = 0) while others involve both young and old subjects (Additional file 1). As expected, the standard deviation is significantly correlated (r = 0.49, P = 4E-5; Figure 3A) with the corresponding LOOCV estimate of the age correlation. In contrast, the size of the data set has no significant relationship with the age correlation (Figure 3B).
                  </p>
                </div>

                <div className="space-y-2.5">
                  <p className="text-justify">
                    A host of technical artifacts could explain differences in predictive accuracy: for example, variations in sample processing, DNA extraction, DNA storage effects, batch effects, and chip effects.
                  </p>
                  <h4 className="font-bold font-sans text-xs text-gray-900 mt-2">
                    DNAm age of multiple tissues from the same subject
                  </h4>
                  <p className="text-justify">
                    In the following, I will address whether DNAm age differs substantially from chronological age. As a first step, I compared the mean DNAm age per tissue with the corresponding mean chronological age. As expected, mean DNAm age per tissue is highly correlated (cor = 0.99; Figure 3C) with the mean chronological age. But breast tissue shows evidence of significant age acceleration. The results of Figure 3C should be interpreted with caution because the analysis included training data sets and involved tissue samples from different subjects.
                  </p>
                  <p className="text-justify">
                    A more interesting analysis is to compare the DNAm ages of tissues collected from the same subjects. DNAm age does not change significantly across different brain regions (temporal cortex, pons, frontal cortex, cerebellum) from the same subjects (Additional file 5K,L). I could only find three human subjects from whom many tissues had been profiled (Figure 3E-G). Although the...
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Horvath Paper Page 5 Layout: Twin Heritability and EMS Evidence Passages */}
          {activePaper.id === 'paper-horvath-2013' && currentPage === 5 && (
            <div className="flex-1 flex flex-col font-serif text-[13.5px] leading-relaxed text-[#24292F] space-y-4">
              <div className="border-b border-gray-100 pb-2">
                <h2 className="font-sans font-bold text-base text-gray-900">
                  Heritability analysis of age acceleration in twins
                </h2>
                <div className="text-xs text-gray-500 font-sans mt-0.5">
                  Twin cohorts GSE36642 (neonatal cord blood) and GSE27317 (older adult peripheral leukocytes)
                </div>
              </div>

              {/* Falconer formula citation callout box */}
              <div
                className={`p-3.5 rounded-lg border transition-all ${
                  highlightedCitation?.pageNumber === 5
                    ? 'bg-amber-50/90 border-amber-300 ring-2 ring-amber-200'
                    : 'bg-[#F9FAFB] border-gray-200'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-sans font-semibold text-xs text-indigo-900 flex items-center gap-1.5">
                    <span className="inline-flex items-center justify-center w-4 h-4 rounded-full bg-indigo-600 text-white text-[10px]">
                      1
                    </span>
                    Falconer's Heritability Formulation & Cohort Estimates
                  </span>
                  <span className="text-[10px] font-mono text-gray-400">Section 3.4</span>
                </div>
                <p className="text-justify leading-relaxed">
                  Heritability of age acceleration was estimated in two twin cohorts using Falconer's formula{' '}
                  <strong className="font-mono bg-white px-1.5 py-0.5 rounded border border-gray-200 text-indigo-900">
                    H² = 2(cor(MZ) – cor(DZ))
                  </strong>
                  . Broad-sense heritability was 100% in newborns and 39% in older adults, with MZ correlations (0.77 newborns, 0.40 older) far exceeding DZ correlations (−0.21 and 0.20).
                </p>
              </div>

              {/* Epigenetic Maintenance System (EMS) Evidence Passage */}
              <div
                className={`p-3.5 rounded-lg border transition-all ${
                  highlightedCitation?.pageNumber === 5
                    ? 'bg-purple-50/90 border-purple-300 ring-2 ring-purple-200'
                    : 'bg-white border-gray-200'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-sans font-semibold text-xs text-purple-900 flex items-center gap-1.5">
                    <span className="inline-flex items-center justify-center w-4 h-4 rounded-full bg-purple-600 text-white text-[10px]">
                      2
                    </span>
                    Support for the Epigenetic Maintenance System (EMS) Model
                  </span>
                  <span className="text-[10px] font-mono text-gray-400">Theoretical Synthesis</span>
                </div>
                <p className="mb-2.5">
                  This supports the epigenetic maintenance system (EMS) model in two ways:
                </p>
                <div className="space-y-2 pl-3 border-l-2 border-purple-200">
                  <p className="text-justify">
                    <strong>1. Developmental tick rate:</strong> The near-total genetic control in newborns implies that the EMS's "tick rate" during development is set by inherited machinery (e.g., maintenance methyltransferases DNMT1, DNMT3A, DNMT3B, and TET family demethylases), consistent with Horvath's claim that high power is required to maintain epigenetic stability during early morphogenesis.
                  </p>
                  <p className="text-justify">
                    <strong>2. Stochastic environmental divergence:</strong> The decline of heritability from 100% in neonates to 39% in older adults highlights cumulative environmental divergence and imperfect repair over the lifespan. As organisms age, stochastic molecular lesions, DNA replication errors, and environmental stressors progressively erode epigenetic fidelity.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 text-xs font-sans text-gray-600 pt-2 border-t border-gray-100">
                <div className="bg-gray-50 p-2.5 rounded border border-gray-200">
                  <span className="font-semibold text-gray-900 block mb-1">Newborn Twin Cohort (GSE36642)</span>
                  <ul className="space-y-0.5 text-[11px]">
                    <li>• Monozygotic (MZ): cor = 0.77 (P = 8.1E-6)</li>
                    <li>• Dizygotic (DZ): cor = -0.21 (P = 0.42)</li>
                    <li>• Broad-sense H²: <strong>100%</strong></li>
                  </ul>
                </div>
                <div className="bg-gray-50 p-2.5 rounded border border-gray-200">
                  <span className="font-semibold text-gray-900 block mb-1">Older Adult Twin Cohort (GSE27317)</span>
                  <ul className="space-y-0.5 text-[11px]">
                    <li>• Monozygotic (MZ): cor = 0.40 (P = 0.01)</li>
                    <li>• Dizygotic (DZ): cor = 0.20 (P = 0.24)</li>
                    <li>• Broad-sense H²: <strong>39%</strong></li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* Standard Page Render for other pages or user uploaded papers */}
          {!(activePaper.id === 'paper-horvath-2013' && (currentPage === 4 || currentPage === 5)) && (
            <div className="flex-1 flex flex-col font-serif text-[13.5px] leading-relaxed text-[#24292F] space-y-4">
              {currentPage === 1 && (
                <div className="border-b border-gray-200 pb-4 mb-2">
                  <h1 className="font-bold font-serif text-xl sm:text-2xl text-gray-950 mb-2 leading-snug">
                    {activePaper.title}
                  </h1>
                  <div className="text-xs font-sans text-gray-600 mb-1">
                    {activePaper.authors.join(', ')}
                  </div>
                  <div className="text-[11px] font-sans text-gray-500 italic">
                    {activePaper.journalOrConference} ({activePaper.year})
                    {activePaper.doi && ` • DOI: ${activePaper.doi}`}
                  </div>
                </div>
              )}

              {/* Render Page Text Paragraphs with Term Highlighting */}
              <div className="space-y-3 font-serif">
                {activePageObj.text
                  .split('\n\n')
                  .filter(p => p.trim().length > 0)
                  .map((paragraph, pIdx) => {
                    const isMatchedBySearch =
                      searchTerm && paragraph.toLowerCase().includes(searchTerm.toLowerCase());
                    const isCitationPassage =
                      highlightedCitation &&
                      highlightedCitation.pageNumber === currentPage &&
                      highlightedCitation.text &&
                      paragraph.includes(highlightedCitation.text.substring(0, 30));

                    return (
                      <p
                        key={pIdx}
                        className={`text-justify leading-relaxed transition-colors ${
                          isCitationPassage
                            ? 'bg-amber-100/70 p-2 rounded border-l-3 border-amber-500'
                            : isMatchedBySearch
                            ? 'bg-yellow-50 p-1 rounded'
                            : ''
                        }`}
                      >
                        {paragraph}
                      </p>
                    );
                  })}
              </div>
            </div>
          )}

          {/* Authentic Document Page Footer */}
          <div className="border-t border-gray-200 pt-2 mt-6 flex justify-between items-center text-[10px] text-gray-400 font-sans">
            <span>{activePaper.journalOrConference || 'PaperPilot AI Research Engine'}</span>
            <span>{activePageObj.footerText || `Page ${currentPage} of ${activePaper.totalPages}`}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
