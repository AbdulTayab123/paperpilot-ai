import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const isProduction = process.env.NODE_ENV === 'production';
const PORT = parseInt(process.env.PORT || '3000', 10);

const app = express();
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Initialize Gemini client if API key is present
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// 1. Evidence-Grounded Q&A Endpoint
app.post('/api/research/ask', async (req: Request, res: Response) => {
  try {
    const { question, passages, documents, model = 'gemini-3.8-flash' } = req.body;

    if (!question) {
      return res.status(400).json({ error: 'Question is required' });
    }

    if (!ai) {
      return res.status(503).json({
        error: 'GEMINI_API_KEY is not configured on the server. Please check your environment variables in AI Studio settings.',
      });
    }

    // Format passages into clearly labeled evidence blocks
    const evidenceText = (passages || [])
      .map((p: { docTitle: string; pageNumber: number; text: string; id: number }) => {
        return `[Source ID: ${p.id}] Document: "${p.docTitle}", Page ${p.pageNumber}\nPassage:\n"${p.text}"\n`;
      })
      .join('\n---\n');

    const prompt = `You are PaperPilot AI, an elite academic research intelligence engine.
Analyze the user question strictly using the provided document evidence passages below.

DOCUMENT EVIDENCE PASSAGES:
${evidenceText || 'No specific document passages provided.'}

USER QUESTION:
"${question}"

STRICT ACADEMIC INTEGRITY INSTRUCTIONS:
1. Answer the question directly and concisely based ONLY on the evidence provided above.
2. In-text citations: Whenever you state a claim or fact, cite the passage index in brackets, e.g., [1], [2]. Use the corresponding Source ID numbers from the evidence.
3. If an answer or part of the answer cannot be supported by the provided text, explicitly state "not stated in the provided text".
4. NEVER invent citations, paper titles, page numbers, DOI, or quotes.
5. Clearly distinguish between direct quotes (use quotation marks), factual findings from the text, and any synthetic reasoning.
6. Provide a concise 2-step summary of your document retrieval and reasoning before the answer (format as: "THOUGHT_STEPS: <step 1> | <step 2>").

Format your final response in this structured format:
THOUGHT_STEPS: Thought and read docs 2 steps
ANSWER: <Your rigorous academic response with citations like [1], [2]>`;

    const response = await ai.models.generateContent({
      model: model || 'gemini-3.8-flash',
      contents: prompt,
      config: {
        temperature: 0.2,
      },
    });

    const rawText = response.text || '';
    let thoughtSteps = 'Thought and read docs 2 steps';
    let answerText = rawText;

    if (rawText.includes('THOUGHT_STEPS:') && rawText.includes('ANSWER:')) {
      const parts = rawText.split('ANSWER:');
      const thoughtPart = parts[0].replace('THOUGHT_STEPS:', '').trim();
      if (thoughtPart) thoughtSteps = thoughtPart;
      answerText = parts[1].trim();
    }

    return res.json({
      answer: answerText,
      thoughtSteps,
      usedPassages: passages,
    });
  } catch (err: any) {
    console.error('Error in /api/research/ask:', err);
    return res.status(500).json({
      error: err?.message || 'Failed to generate answer from research evidence.',
    });
  }
});

// 2. Paper Comparison Matrix Endpoint
app.post('/api/research/compare', async (req: Request, res: Response) => {
  try {
    const { papers, criteria } = req.body;

    if (!papers || !Array.isArray(papers) || papers.length < 2) {
      return res.status(400).json({ error: 'Please select at least two papers to compare' });
    }

    if (!ai) {
      return res.status(503).json({
        error: 'GEMINI_API_KEY is not configured on the server.',
      });
    }

    const papersSummary = papers.map((p: any, idx: number) => {
      return `PAPER ${idx + 1}:
Title: ${p.title}
Authors: ${p.authors || 'Not stated'}
Year: ${p.year || 'Not stated'}
Text Sample/Excerpts:
${p.text ? p.text.substring(0, 4000) : 'No text content provided'}
`;
    }).join('\n=================\n');

    const prompt = `You are PaperPilot AI. Perform a rigorous comparative literature matrix across the following papers.
Analyze each paper across these dimensions:
1. Research Objectives / Primary Question
2. Methodology / Technical Approach
3. Datasets / Samples / Benchmarks
4. Key Results & Findings
5. Stated Limitations
6. Future Work / Unresolved Questions

CRITICAL: If a dimension or detail is missing or not mentioned in a paper's text, you MUST mark it as "Not stated in the provided text." Do NOT hallucinate.

PAPERS:
${papersSummary}

Return a valid JSON object matching this schema:
{
  "comparisonMatrix": [
    {
      "dimension": "Research Objectives",
      "findings": [
        { "paperTitle": "...", "content": "...", "citedPage": "..." }
      ]
    },
    ...
  ],
  "synthesis": "Short paragraph synthesizing the consensus and divergences across the selected papers."
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);
  } catch (err: any) {
    console.error('Error in /api/research/compare:', err);
    return res.status(500).json({
      error: err?.message || 'Failed to generate paper comparison matrix.',
    });
  }
});

// 3. Research Gaps & Hypothesis Exploration
app.post('/api/research/gaps', async (req: Request, res: Response) => {
  try {
    const { papers } = req.body;

    if (!papers || papers.length === 0) {
      return res.status(400).json({ error: 'Papers are required' });
    }

    if (!ai) {
      return res.status(503).json({
        error: 'GEMINI_API_KEY is not configured on the server.',
      });
    }

    const papersSummary = papers.map((p: any) => `Title: ${p.title}\nContent:\n${(p.text || '').substring(0, 3000)}`).join('\n---\n');

    const prompt = `You are PaperPilot AI. Based on the following research documents, identify unexplored research gaps, conflicting methodologies, or potential next-generation questions.

MANDATORY INTEGRITY REQUIREMENT:
Every suggested gap must be explicitly tagged as a "Hypothesis requiring literature verification", NOT an established empirical fact.

PAPERS:
${papersSummary}

Return a JSON array of gaps:
[
  {
    "gapTitle": "...",
    "category": "Methodological | Empirical | Population/Dataset | Theoretical",
    "observation": "What the current papers show or omit",
    "hypothesis": "Hypothesis requiring literature verification: ...",
    "suggestedStudy": "Proposed experimental or observational study to investigate this gap"
  }
]`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '[]');
    return res.json({ gaps: parsed });
  } catch (err: any) {
    console.error('Error in /api/research/gaps:', err);
    return res.status(500).json({
      error: err?.message || 'Failed to explore research gaps.',
    });
  }
});

// Mount Vite or static assets
async function startServer() {
  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`PaperPilot AI server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
