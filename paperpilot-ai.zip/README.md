# PaperPilot AI 🧭📄

**PaperPilot AI** is an evidence-grounded research intelligence and literature workspace engineered for university students, researchers, and graduate applicants. It delivers a document-first reading experience with page-level citation tracking, cross-paper comparison matrices, literature gap exploration, and verifiable Q&A.

---

## 🔬 Core Capabilities

### 1. Document Reading & PDF Viewer
- **Authentic Academic Typesetting:** Off-white canvas, two-column layout, figures, charts, and header/footer indicators.
- **Page-Level Navigation:** `< 5 of 20 >` with direct page input and jump controls.
- **Zoom & Search Controls:** 50% to 150% magnification, in-document keyword search with matched-phrase highlights.
- **Interactive Citation Anchors:** Clicking citations in the AI evidence panel scrolls directly to the referenced page and highlights the exact sentence.

### 2. Evidence-Grounded Q&A
- **Strict Evidence Grounding:** Answers are formulated strictly from retrieved passages.
- **In-Text Citation Badges:** Every claim is cited as `[1]`, `[2]` linked to the document name and original page number.
- **Zero Hallucination Guarantee:** If requested information is absent from the provided text, the system explicitly reports *"not stated in the provided text"*.
- **Collapsible Reasoning Steps:** "Thought and read docs 2 steps" reveals the retrieval path and query terms.

### 3. Literature Comparison Matrix
- Side-by-side comparative analysis of 2 or more research papers across 6 key dimensions:
  1. Research Objectives / Primary Question
  2. Methodology & Technical Approach
  3. Datasets, Cohorts & Benchmarks
  4. Key Empirical Findings
  5. Stated Limitations
  6. Future Directions
- Download matrix as structured CSV or Markdown.

### 4. Research Gap & Hypothesis Exploration
- Analyzes complementary or diverging papers to formulate novel investigation gaps.
- Explicitly marked as **"Hypothesis requiring literature verification"** rather than established facts.

### 5. Document Library & Real Uploads
- Supports uploading real `.pdf` and `.txt` files with drag-and-drop.
- Extracts page text via client-side PDF.js, preserving original 1-indexed page boundaries.
- Detects scanned image PDFs and displays clear OCR requirement alerts.
- Filter, organize into folders, search by keyword, tag, or collection.

---

## 🛠️ Tech Stack & Architecture

- **Frontend:** React 19, TypeScript, Tailwind CSS, Lucide React, Motion.
- **PDF Engine:** `pdfjs-dist` for real page extraction and canvas rendering.
- **Backend:** Express with TypeScript (`tsx`), Vite middleware mode.
- **AI Integration:** `@google/genai` on server side (`gemini-3.8-flash`, `gemini-3.1-pro-preview`) with API keys securely kept on the backend.

---

## 🚀 Getting Started

### 1. Environment Variables
Create a `.env` file from `.env.example`:
```bash
GEMINI_API_KEY="your-gemini-api-key"
PORT=3000
```

### 2. Development
```bash
# Install dependencies
npm install

# Start the full-stack server (runs Express + Vite middleware on port 3000)
npm run dev
```

### 3. Testing
```bash
npm test
```

### 4. Build & Production Deployment
```bash
# Build frontend assets
npm run build

# Start production server
npm start
```
