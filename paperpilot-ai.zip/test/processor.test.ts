import assert from 'node:assert';
import test from 'node:test';
import { retrievePassages } from '../src/utils/documentProcessor.ts';
import { samplePapers } from '../src/data/samplePapers.ts';

test('retrievePassages finds twin heritability passage in Horvath 2013 on Page 5', () => {
  const query = 'How does heritability analysis of age acceleration in twins support epigenetic maintenance?';
  const passages = retrievePassages(query, samplePapers, 3);

  assert.ok(passages.length > 0, 'Should retrieve at least one passage');
  assert.ok(passages.some(p => p.docId === 'paper-horvath-2013' && p.pageNumber === 5));
  assert.ok(passages.some(p => /Falconer/i.test(p.passageText)));
});

test('retrievePassages returns indexed citations with 1-based indices', () => {
  const query = 'senolytics dasatinib quercetin';
  const passages = retrievePassages(query, samplePapers, 2);

  assert.ok(passages.length > 0);
  assert.strictEqual(passages[0].id, 1);
  if (passages[1]) {
    assert.strictEqual(passages[1].id, 2);
  }
});

test('sample papers include all necessary metadata and page numbers', () => {
  for (const paper of samplePapers) {
    assert.ok(paper.id, 'Paper should have an id');
    assert.ok(paper.title, 'Paper should have a title');
    assert.ok(paper.totalPages > 0, 'Paper should have total pages');
    assert.ok(paper.pages.length > 0, 'Paper should have pages array');
    paper.pages.forEach(p => {
      assert.ok(p.pageNumber >= 1, 'Page numbers must be 1-indexed');
      assert.ok(p.text.length > 0, 'Page must have text content');
    });
  }
});
